// Databricks notebook source
// MAGIC %md
// MAGIC # Checking for any datasrc rows with int_claim* - some domains will have rows of this type which need to filtered out.

// COMMAND ----------

// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

val base_path=f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2"

// COMMAND ----------

def patIDX(parq_file: String): org.apache.spark.sql.DataFrame = {
    val pat_idx=spark.read.parquet(parq_file).select("ps_cci_member_id").distinct()  
    return(pat_idx)
}

// COMMAND ----------

val px_idx=patIDX(f"$base_path/px_raw")
px_idx.show()

// COMMAND ----------



// COMMAND ----------

// DBTITLE 1,Procedure
val parq_file=f"$base_path/px_raw"
display(spark.read.parquet(parq_file)
             .groupBy("proc_emr_source")
             .count()
             .filter($"proc_emr_source".like("int_claim%")))

// COMMAND ----------

// DBTITLE 1,Diagnosis 23
val parq_file=f"$base_path/dx_23_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("diag_emr_source").count().filter($"diag_emr_source".like("int_claim%")))

// COMMAND ----------

// DBTITLE 1,Diagnosis 24
val parq_file=f"$base_path/dx_24_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("diag_emr_source").count().filter($"diag_emr_source".like("int_claim%")))

// COMMAND ----------

// DBTITLE 1,Clinical Encounter
val parq_file=f"$base_path/enc_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("enc_emr_source").count().filter($"enc_emr_source".like("int_claim%")))

// COMMAND ----------

// DBTITLE 1,Observation
val parq_file=f"$base_path/obs_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("obs_emr_source").count().filter($"obs_emr_source".like("int_claim%")))

// COMMAND ----------

// DBTITLE 1,RX Patient Report
val parq_file=f"$base_path/rxr_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("rxpat_emr_source").count().filter($"rxpat_emr_source".like("int_claim%")))

// COMMAND ----------

// DBTITLE 1,RX Admin
val parq_file=f"$base_path/rxa_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("rxadm_emr_source").count().filter($"rxadm_emr_source".like("int_claim%")))

// COMMAND ----------

// DBTITLE 1,RX Order
val parq_file=f"$base_path/rxo_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("rxord_emr_source").count().filter($"rxord_emr_source".like("int_claim%")))


// COMMAND ----------

// DBTITLE 1,Lab Results
val parq_file=f"$base_path/lab_raw"
//spark.read.parquet(parq_file).columns
display(spark.read.parquet(parq_file).groupBy("labres_emr_source").count().filter($"labres_emr_source".like("int_claim%")))