// Databricks notebook source
// DBTITLE 1,The Filesystem shows the path
// MAGIC %fs
// MAGIC ls 

// COMMAND ----------

// DBTITLE 1,User is there
// MAGIC %fs
// MAGIC ls dbfs:/user/

// COMMAND ----------

// DBTITLE 1,Our Mount/Path is broken!!
// MAGIC %fs
// MAGIC ls dbfs:/mnt/jvmlstorage2fs/

// COMMAND ----------

// DBTITLE 1,Upstream Broken too
// MAGIC %fs
// MAGIC ls dbfs:/mnt

// COMMAND ----------

// DBTITLE 1,Check Mounts
display(dbutils.fs.mounts())

// COMMAND ----------

// MAGIC %python
// MAGIC for mount in dbutils.fs.mounts():
// MAGIC     if mount.mountPoint == "/mnt/jvmlshare":
// MAGIC         print(f"Mount Point: {mount.mountPoint}, Source: {mount.source}")

// COMMAND ----------

dbutils.fs.refreshMounts()

// COMMAND ----------

// MAGIC %fs
// MAGIC ls dbfs:/mnt/jvmlstorage2fs/