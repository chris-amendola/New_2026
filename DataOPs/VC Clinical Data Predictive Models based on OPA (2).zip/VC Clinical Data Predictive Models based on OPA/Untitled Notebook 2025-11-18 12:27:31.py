# Databricks notebook source
from xgboost.spark import SparkXGBClassifier

clf=SparkXGBClassifier()
obj_param=clf.getOrDefault("objective")
print(obj_param)

# COMMAND ----------

# MAGIC %md
# MAGIC The SparkXGBClassifier does not expose an objective parameter for users to set directly. This is by design: the classifier automatically selects the appropriate objective function based on the task (e.g., binary or multiclass classification). Allowing users to set a custom objective is not supported in the SparkXGBClassifier API, unlike the native XGBoost Python API where you can specify custom objectives

# COMMAND ----------

