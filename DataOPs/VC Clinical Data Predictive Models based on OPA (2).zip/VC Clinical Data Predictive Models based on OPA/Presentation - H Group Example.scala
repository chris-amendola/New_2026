// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")
val retro_pats_idx=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/retro_pats_idx")
val enc_map = spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv")

val disp_cat_map=spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_disp_cat.csv")

val enc_raw=spark.read.parquet(f"$base_path/enc_raw")
                 .withColumn("arrive_date",to_date($"enc_arrivaldate","ddMMMyyyy"))
                 .withColumn("admit_date",to_date($"enc_admitdate","ddMMMyyyy"))
                 .withColumn( "disch_date"
                              ,when(col( "discharge_date").isNull
                                        ,col("arrive_date"))
                              .otherwise(to_date($"discharge_date","ddMMMyyyy")))
                 .join( drop_dops
                       ,"ps_cci_member_id"
                       ,"left_anti")

val enc_prep=enc_raw.filter($"arrive_date".between(startDate,endDate))
                    .join(enc_map,enc_raw("hts_patient_type_cui")===enc_map("CUI_CODE"),"left")
                    .join(disp_cat_map,enc_raw("discharge_disp_m")===disp_cat_map("Concept_CUI"),"left")

val hgrp_freq=enc_prep.select( "ps_cci_member_id"
                              ,"enc_groupid")
                            //,"arrive_date")
                      .distinct()
                      .groupBy("enc_groupid")
                      .agg(count("*").as("hgrp_fq")) 

val enc_hgrp=enc_prep.select( "ps_cci_member_id"
                             ,"enc_groupid" //,"arrive_date"
                             ,"Label" //"hts_patient_type_cui"
                             )
                     .distinct()
                     .groupBy("enc_groupid","Label")//"hts_patient_type_cui")
                     .agg(count("*").as("enc_fq")) 
                     
val q= hgrp_freq.join(enc_hgrp,Seq("enc_groupid"),"left")
                  .withColumn("prop",$"enc_fq"/$"hgrp_fq")

// COMMAND ----------

// DBTITLE 1,H770958 -Hutchinson Clinic
// MAGIC %md
// MAGIC
// MAGIC ## H770958 - Hutchinson Clinic
// MAGIC
// MAGIC https://www.hutchclinic.com/
// MAGIC
// MAGIC ![HutchinsonClinic_001.jpg](./art/HutchinsonClinic_001.jpg "HutchinsonClinic_001.jpg")
// MAGIC
// MAGIC ![HutchinsonClinic_002.jpg](./art/HutchinsonClinic_002.jpg "HutchinsonClinic_002.jpg")
// MAGIC
// MAGIC
// MAGIC

// COMMAND ----------

// MAGIC %md
// MAGIC
// MAGIC ### Patient Encounter Types almost exclusively Office Visits
// MAGIC
// MAGIC

// COMMAND ----------

display(q)

// COMMAND ----------

// MAGIC %md
// MAGIC ### Is the data from this source "Invalid"?
// MAGIC
// MAGIC ### Should we, without prior knowledge of an analytic use case discard this data?
// MAGIC
// MAGIC ### Should we create patient markers from this data?

// COMMAND ----------

// MAGIC %md
// MAGIC
// MAGIC ## H984216 - Ascension
// MAGIC https://healthcare.ascension.org/
// MAGIC
// MAGIC ![Ascension_001.jpg](./art/Ascension_001.jpg "Ascension_001.jpg")
// MAGIC
// MAGIC

// COMMAND ----------

// MAGIC %md
// MAGIC ### Patient Encounter Types - More Typical Distribution
// MAGIC

// COMMAND ----------

display(q)

// COMMAND ----------

// MAGIC %md
// MAGIC ### Is the data from this source Valid?
// MAGIC
// MAGIC ### Should we, without prior knowledge of an analytic use case discard this data?
// MAGIC
// MAGIC ### Should we create patient markers from this data?

// COMMAND ----------

// MAGIC %md
// MAGIC ### Ascension has presence in Kansas - as does Hutchinson Clinic
// MAGIC
// MAGIC ![Ascension_002.jpg](./art/Ascension_002.jpg "Ascension_002.jpg")

// COMMAND ----------

val multi_members=enc_prep.select( "ps_cci_member_id"
                                  ,"enc_groupid")
                                  //,"arrive_date")
                          .distinct()
                          .groupBy("ps_cci_member_id")
                          .count().filter($"count">1)
val mm_hgrp=multi_members.select("ps_cci_member_id").join(enc_prep.select( "ps_cci_member_id","enc_groupid").distinct(),Seq("ps_cci_member_id"),"left")

// COMMAND ----------

// MAGIC %md
// MAGIC ### Patients that might show up in both sources?
// MAGIC
// MAGIC

// COMMAND ----------

display(
  mm_hgrp.select($"ps_cci_member_id",$"enc_groupid".as("a_id"))
         .join( mm_hgrp.select($"ps_cci_member_id",$"enc_groupid".as("b_id"))
               ,Seq("ps_cci_member_id")
               ,"inner")
         .filter($"a_id"=!=$"b_id").groupBy($"a_id",$"b_id").agg(count("*").as("value"))
  )

// COMMAND ----------

display(
  enc_prep.select( "ps_cci_member_id"
                ,"enc_groupid")
              //,"arrive_date")
         .distinct()
         .groupBy("ps_cci_member_id")
         .agg(count("*").as("HGRP_Count")).groupBy("HGRP_Count").agg(count("*").as("Pat_Count"))
)  