# Databricks notebook source
# MAGIC %fs
# MAGIC ls dbfs:/mnt/jvmlstorage2fs/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/

# COMMAND ----------

# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

drop_dops=spark.read.parquet(f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/chimera")

# COMMAND ----------

enc_map = (spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv"))

idx_dx_23 = (
    spark.read.parquet(f"{base_path}/dx_23_raw/")
    .filter(~col("diag_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_dx_23", lit(1))
)
print("DX_23:")
print(idx_dx_23.count())

idx_dx_24 = (
    spark.read.parquet(f"{base_path}/dx_24_raw/")
    .filter(~col("diag_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_dx_24", lit(1))
)
print("DX_24:")
print(idx_dx_24.count())

idx_enc = (
    spark.read.parquet(f"{base_path}/enc_raw/")
    .filter(~col("enc_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .join(enc_map,col("hts_patient_type_cui")==col("CUI_CODE"),"left")
    .filter(~(col("Label").isNull()))
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_enc", lit(1))
)
print("Encounter:")
print(idx_enc.count())

idx_obs = (
    spark.read.parquet(f"{base_path}/obs_raw/")
    .filter(~col("obs_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_obs", lit(1))
)
print("OBS:")
print(idx_obs.count())

idx_px = (
    spark.read.parquet(f"{base_path}/px_raw/")
    .filter(~col("proc_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_px", lit(1))
)
print("PX:")
print(idx_px.count())

idx_rx0 = (
    spark.read.parquet(f"{base_path}/rxo_raw/")
    .filter(~col("rxord_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rx0", lit(1))
)
print("RX0:")
print(idx_rx0.count())

idx_rxa = (
    spark.read.parquet(f"{base_path}/rxa_raw/")
    .filter(~col("rxadm_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rxa", lit(1))
)
print("RXA:")
print(idx_rxa.count())

idx_rxr = (
    spark.read.parquet(f"{base_path}/rxr_raw/")
    .filter(~col("rxpat_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rxr", lit(1))
)
print("RXR:")
print(idx_rxr.count())

idx_lab = (
    spark.read.parquet(f"{base_path}/lab_raw/")
    .filter(~col("labres_emr_source").like("int_claim%"))
    .join( drop_dops
          ,"ps_cci_member_id"
          ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_lab", lit(1))
)
print("LAB:")
print(idx_lab.count())

# COMMAND ----------

from pyspark.sql import DataFrame
idxToJoin: list[DataFrame] = [idx_dx_24, idx_enc, idx_obs, idx_px, idx_rx0, idx_rxa, idx_rxr, idx_lab]

# COMMAND ----------

from functools import reduce

allPatKey = reduce(
    lambda accIdx, currentIdx: accIdx.join(
        currentIdx,
        on=["ps_cci_member_id"],
        how="fullouter"
    ),
    idxToJoin,
    idx_dx_23
).withColumn(
        "idx_dx",
        when((col("idx_dx_24") == 1) | (col("idx_dx_23") == 1), 1).otherwise(0)
).withColumn( "idx_rx",
        when((col("idx_rx0") == 1) | (col("idx_rxr") == 1) | (col("idx_rxa") == 1), 1).otherwise(0)     

)

# COMMAND ----------

display(
    allPatKey.select( col("ps_cci_member_id").alias("Patient") 
                 ,col("idx_enc").alias("Encounter") 
                 ,col("idx_obs").alias("Observation") 
                 ,col("idx_px").alias("Procedure") 
                 ,col("idx_lab").alias("Lab Results") 
                 ,col("idx_dx").alias("Diagnosis")
                 ,col("idx_rx").alias("Medications") )
)

# COMMAND ----------

allPatKey.count()

# COMMAND ----------

import itertools
feature_cols = ["idx_dx","idx_enc", "idx_obs", "idx_px", "idx_rx", "idx_lab"]

pairs = list(itertools.combinations(feature_cols, 2))

co_occurrence = []
for a, b in pairs:
    count = allPatKey.filter((col(a) == 1) & (col(b) == 1)).count()
    co_occurrence.append((a, b, count))

co_occur=spark.createDataFrame(co_occurrence, ["var1", "var2", "co_occurrence"])
display(co_occur)


# COMMAND ----------

capture_counts=allPatKey.agg(
        sum("idx_dx").alias("idx_dx"),
        sum("idx_enc").alias("idx_enc"),
        sum("idx_obs").alias("idx_obs"),
        sum("idx_px").alias("idx_px"),
        sum("idx_rx").alias("idx_rx"),
        sum("idx_lab").alias("idx_lab"))  \
        .withColumn("piv_point",lit("piv")) \
      .unpivot( ids=["piv_point"]
               ,values=["idx_dx","idx_enc","idx_obs","idx_px","idx_rx","idx_lab"]
               ,variableColumnName="key",valueColumnName="value") \
      .withColumn("Found",col("value")/allPatKey.count()
     ).withColumn("Not Found",lit(1)-col("Found")
     ).withColumn("patients",col("value")
     ).withColumn("missing",lit(allPatKey.count())-col("value"))

display(capture_counts)   
# Persist the dataframe to a table
#capture_counts.write.mode("overwrite").saveAsTable("capture_counts")


# COMMAND ----------

# MAGIC %md
# MAGIC ![USA_on_DRUGS.jpg](./USA_on_DRUGS.jpg "USA_on_DRUGS.jpg")
# MAGIC
# MAGIC Regarding Labs:
# MAGIC https://www.cdc.gov/nchs/data/nhsr/nhsr184.pdf

# COMMAND ----------

allPatKey.groupBy("ps_cci_member_id").count().filter(col("count") > 1).show()

# COMMAND ----------

# DBTITLE 1,Capture Recapture Analysis
cap_matrix = (
    allPatKey
    .select(
        "idx_dx",
        "idx_enc",
        "idx_obs",
        "idx_px",
        "idx_rx",
        "idx_lab"
    )
    .groupBy(
        "idx_dx",
        "idx_enc",
        "idx_obs",
        "idx_px",
        "idx_rx",
        "idx_lab"
    )
    .count()
    .na.fill(0)
)

display(cap_matrix)
# Persist the dataframe to a table
#cap_matrix.write.mode("overwrite").saveAsTable("cap_matrix")

# COMMAND ----------

# Read saved cap_matrix table
cap_matrix = spark.read.table("cap_matrix")
cap_matrix.show(5)

# COMMAND ----------

# DBTITLE 1,Mt Model 
from pyspark.ml.feature import VectorAssembler, Interaction
from math import exp
from itertools import combinations

# Assemble features
# Define Feature Columns
cap_matrix=cap_matrix.withColumn("hi_int_enc",when(col("idx_enc")==1,0).otherwise(1)) \
                      .withColumn("hi_int_rx",when(col("idx_rx")==1,0).otherwise(1)) \
                      .withColumn("hi_int_lab",when(col("idx_lab")==1,0).otherwise(1)) \
                      .withColumn("hi_int_dx",when(col("idx_dx")==1,1).otherwise(0)) \
                      .withColumn("hi_int_px",when(col("idx_dx")==1,1).otherwise(0)) \
                      .withColumn("hi_int_obs",when(col("idx_obs")==1,1).otherwise(0))
#Create an all occcasions marker
cap_matrix=cap_matrix.withColumn( "all"
                                 ,when((col("idx_dx")==1) & (col("idx_enc")==1) & (col("idx_obs")==1) & (col("idx_px")==1) & (col("idx_rx")==1) & (col("idx_lab")==1), 0).otherwise(1)
                                 ).withColumn("three_a"
                                 ,when((col("idx_dx")==1) & (col("idx_obs")==1) & (col("idx_px")==1), 1).otherwise(0))

feature_cols = ["idx_dx","idx_enc", "idx_obs", "idx_px", "idx_rx", "idx_lab","all"]
intensity_cols = ["hi_int_enc","hi_int_rx","hi_int_lab","hi_int_dx","hi_int_px","hi_int_obs"]
intx_cols=[]

main_effects=feature_cols + intensity_cols

df=cap_matrix

# All pairwise interactions
from itertools import combinations
for (c1,c2) in combinations((main_effects), 2):
    intx_cols.append(f"{c1}*{c2}")
    df=df.withColumn(f"{c1}*{c2}", df[c1] * df[c2])

df.write.mode("overwrite").saveAsTable("cap_recap")

#: Use only intensity interactions
intx_cols=[ 'idx_dx*hi_int_dx'
           ,'idx_px*hi_int_px'
           ,'idx_obs*hi_int_obs'
           ,'idx_dx*all'
           ,'idx_px*all'
           ,'idx_rx*all'
           ,'idx_lab*all'
           ,'idx_enc*all'
           ,'idx_obs*all']

#: Over-Ride
# main_effects=feature_cols
zmain_effects=['idx_enc',
'idx_obs',
'idx_px',
'idx_rx',
'idx_lab',
'hi_int_enc',
'hi_int_rx',
'hi_int_lab',
'hi_int_obs',
'idx_dx*idx_enc',
'idx_dx*idx_obs',
'idx_dx*idx_px',
'idx_dx*idx_rx',
'idx_dx*hi_int_enc',
'idx_dx*hi_int_rx',
'idx_dx*hi_int_obs',
'idx_enc*idx_obs',
'idx_enc*idx_px',
'idx_enc*idx_rx',
'idx_enc*idx_lab',
'idx_enc*hi_int_rx',
'idx_enc*hi_int_lab',
'idx_enc*hi_int_dx',
'idx_enc*hi_int_px',
'idx_enc*hi_int_obs',
'idx_obs*idx_px',
'idx_obs*idx_rx',
'idx_obs*idx_lab',
'idx_obs*hi_int_enc',
'idx_obs*hi_int_rx',
'idx_obs*hi_int_lab',
'idx_obs*hi_int_dx',
'idx_obs*hi_int_px',
'idx_obs*hi_int_obs',
'idx_px*idx_rx',
'idx_px*idx_lab',
'idx_px*hi_int_enc',
'idx_px*hi_int_rx',
'idx_px*hi_int_lab',
'idx_px*hi_int_dx',
'idx_px*hi_int_px',
'idx_px*hi_int_obs',
'idx_rx*idx_lab',
'idx_rx*hi_int_lab',
'idx_rx*hi_int_dx',
'idx_rx*hi_int_px',
'idx_rx*hi_int_obs',
'idx_lab*hi_int_enc',
'idx_lab*hi_int_rx',
'idx_lab*hi_int_obs',
'hi_int_enc*hi_int_rx',
'hi_int_enc*hi_int_lab',
'hi_int_enc*hi_int_dx',
'hi_int_enc*hi_int_px',
'hi_int_enc*hi_int_obs',
'hi_int_rx*hi_int_lab',
'hi_int_rx*hi_int_dx',
'hi_int_rx*hi_int_px',
'hi_int_rx*hi_int_obs',
'hi_int_lab*hi_int_obs',
'hi_int_dx*hi_int_obs',
'hi_int_px*hi_int_obs','all']

print(f"Selected Features: {main_effects+intx_cols}")
print(f"Number: {len(main_effects+intx_cols)}")
assembler=VectorAssembler( inputCols=main_effects+intx_cols
                          ,outputCol="features")

cap_matrix_vec=assembler.transform(df)

display(cap_matrix_vec)

# COMMAND ----------



# COMMAND ----------

from pyspark.ml.regression import GeneralizedLinearRegression
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

# Assign Model Features and label
glm = GeneralizedLinearRegression( featuresCol="features"
                                  ,labelCol="count")

# Define a parameter grid for tuning
paramGrid = ParamGridBuilder() \
    .addGrid(glm.family, ["poisson"]) \
    .addGrid(glm.link, ["log"]) \
    .addGrid(glm.regParam, [0.0, 0.2, 1.0]) \
    .addGrid(glm.maxIter, [10, 50]) \
    .build()

# Define an evaluator
evaluator = RegressionEvaluator( labelCol="count"
                                ,predictionCol="prediction"
                                ,metricName="rmse")

# Set up CrossValidator
crossval = CrossValidator( estimator=glm
                          ,estimatorParamMaps=paramGrid
                          ,evaluator=evaluator
                          ,numFolds=5)  
crossval.setParallelism(4)

# Models away
cvModel = crossval.fit(cap_matrix_vec)

bestModel = cvModel.bestModel

print("Best RegParam:", bestModel.getRegParam())
print("Best MaxIter:", bestModel.getMaxIter())

# COMMAND ----------

# Make predictions
predictions = bestModel.transform(cap_matrix_vec)
#predictions.show()

# Evaluate the model
evaluator_rmse = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="rmse")
evaluator_r2 = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="r2")
evaluator_mae = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="mae")
evaluator_mse = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="mse")
evaluator_var = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="var")

rmse = evaluator_rmse.evaluate(predictions)
r2 = evaluator_r2.evaluate(predictions)
mae = evaluator_mae.evaluate(predictions)
mse = evaluator_mse.evaluate(predictions)
var = evaluator_var.evaluate(predictions)


# Print metrics
print(f"Root Mean Squared Error (RMSE): {rmse}")
print(f"R Squared (R²): {r2}")
print(f"Mean Absolute Error (MAE): {mae}")
print(f"Mean Squared Error (MSE): {mse}")
print(f"Variance Explained: {var}")

# COMMAND ----------

from pyspark.sql.functions import exp
# Predict the unobserved count (0, 0 history)
# Create a DataFrame for the unobserved history
unobserved_data = [(0.0,) * len(main_effects+intx_cols)]
unobserved_df = spark.createDataFrame(unobserved_data, main_effects+intx_cols)
assembled_unobserved_df = assembler.transform(unobserved_df)
#assembled_unobserved_df.show()

# Use the model to predict the expected count for the (0, 0) history
predicted_unobserved_df = bestModel.transform(assembled_unobserved_df)
#predicted_unobserved_df.show()
predicted_unobserved_count = predicted_unobserved_df.select(col("prediction").alias("estimated_count")).collect()[0]["estimated_count"]

print(f"Estimated unobserved count: {predicted_unobserved_count}")

# Estimate the total population size
total_observed_count = cap_matrix_vec.agg(sum("count")).collect()[0][0]
estimated_total_population = total_observed_count + predicted_unobserved_count

print(f"Total observed count: {total_observed_count}")
print(f"Estimated total population size: {estimated_total_population}")


# COMMAND ----------

import math
# Map coefficients to feature names

feature_names = assembler.getInputCols()
coefficients_with_features = list(zip(feature_names, bestModel.coefficients))
for feature, coef in coefficients_with_features:
    rev_log=math.exp(coef)
    print(f"{feature} => {coef}, {rev_log}")
    if abs(coef) >=.1:
        z=1
        #print(f"'{feature}',")

# COMMAND ----------

#print(bestModel.summary)

# COMMAND ----------

residuals = predictions.withColumn("residual", col("count") - col("prediction"))

# Check for overdispersion
from pyspark.sql.functions import mean, variance
stats = residuals.select(
    mean("residual").alias("mean_residual"),
    variance("residual").alias("variance_residual")
).collect()

mean_residual = stats[0]["mean_residual"]
variance_residual = stats[0]["variance_residual"]

print(f"Mean of residuals: {mean_residual}")
print(f"Variance of residuals: {variance_residual}")

if variance_residual > mean_residual:
    print("Overdispersion detected!")
else:
    print("No overdispersion detected.")

# Goodness of fit metrics
print(f"\nNull Deviance: {bestModel.summary.nullDeviance}")
print(f"Residual Deviance: {bestModel.summary.deviance}")    

# COMMAND ----------

# DBTITLE 1,Residual Analysis
import matplotlib.pyplot as plt

residuals_df = bestModel.summary.residuals(residualsType="pearson") 
residuals = residuals_df.select("pearsonResiduals").rdd.flatMap(lambda x: x).collect()
fitted = bestModel.summary.predictions.select("prediction").rdd.flatMap(lambda x: x).collect()

plt.scatter(fitted, residuals, alpha=0.5)
plt.axhline(0, color='red', linestyle='--')
plt.xlabel("Fitted Values")
plt.ylabel("Pearson Residuals")
plt.title("Residual vs Fitted Plot")
plt.show()

# COMMAND ----------

# DBTITLE 1,Dispersion
# Goodness of fit metrics
print(f"Null Deviance: {bestModel.summary.nullDeviance}")
print(f"Residual Deviance: {bestModel.summary.deviance}")

# COMMAND ----------

display(predictions.withColumn("residual", col("count") - col("prediction")))

# COMMAND ----------

display(bestModel.summary.residuals(residualsType="pearson")) 