# Databricks notebook source
# DBTITLE 1,Config
# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

# DBTITLE 1,Outcome
outcome=spark.table("ach_outcome") \
             .withColumn("admit",lit(1))
include=spark.table("ach_dem_elig") \
             .withColumn("inc",lit(1))

ach_outcome=include.join(outcome,on="ps_cci_member_id",how="left") \
                   .filter((col("months_tot")>=12) | (col("admit")==1) & (col("dod_outcome") == 1)) \
                   .select("ps_cci_member_id","admit") \
                   .distinct() \
                   .fillna(0)  
idx=ach_outcome.select("ps_cci_member_id")
print("Total Patient Count:",idx)
print("Unique Patient Count:",ach_outcome.count())
print("Patients Count:")                   
print(ach_outcome.count())
print("Duplicate ID Test(Empty Table is PASS)")
ach_outcome.groupBy("ps_cci_member_id").count().filter(col("count")>1).show()
print("Event Count:")
ach_outcome.groupBy("admit").count().show()

# COMMAND ----------

# DBTITLE 1,Look for Imbalance in Outcomes
total=ach_outcome.count()
display(ach_outcome.groupBy("admit") \
                   .count() \
                   .withColumn( "Percent"
                               , ((col("count") / total) * 100)
))

# COMMAND ----------

# DBTITLE 1,MARKER Selection
# Demographic Markers
demographic=idx.join(spark.table("MARKERS.demographic"),on="ps_cci_member_id",how="inner")
demographic.show(5)
print("Demographic:")
print(demographic.count())

# Medication Markers
medication=idx.join(spark.table("MARKERS.medication"),on="ps_cci_member_id",how="inner").withColumnRenamed("drug_count","value")
medication.show(5)
print("Medication:")
print(medication.count())

# Condition Markers
condition=idx.join(spark.table("MARKERS.condition"),on="ps_cci_member_id",how="inner")
condition.show(5)
print("Condition:")
print(condition.count())

#Lab Results Markers
labres=idx.join(spark.table("MARKERS.lab_results"),on="ps_cci_member_id",how="inner")
labres.show(5)
print("Lab Results:")
print(labres.count())

# Combine
markers_incoming=demographic \
                   .union(medication) \
                   .union(condition) \
                   .union(labres)   

# COMMAND ----------

# DBTITLE 1,Remove Low Count Markers (n<30)
low_prev_markers=(markers_incoming.groupBy("marker")
                                 .count()
                                 .filter(col("count")<lit(30)))
markers=markers_incoming.join(low_prev_markers,how="leftanti",on="marker")  
display(markers)

feature_cols=markers.select("marker").distinct().rdd.map(lambda x: x['marker']).collect()
print(feature_cols)                  

# COMMAND ----------

# DBTITLE 1,Marker Pivot
markers_array=markers.groupBy("ps_cci_member_id") \
                         .pivot("marker") \
                         .count().na.fill(0)
display(markers_array)

# COMMAND ----------

model_df=ach_outcome.join( markers_array
                          ,on="ps_cci_member_id"
                          ,how="inner")

# COMMAND ----------

# DBTITLE 1,Feature Assembly
from pyspark.ml.feature import VectorAssembler
assembler=VectorAssembler( inputCols=feature_cols
                          ,outputCol="features")

vec_df=assembler.transform(model_df)

# COMMAND ----------

# DBTITLE 1,Class Imbalance in final outcome distribution
vec_df.groupBy("admit").count().show()
# Scalee weight
neg_count=vec_df.filter(col("admit")==0).count()
pos_count=vec_df.filter(col("admit")==1).count()
scale_weight=neg_count/pos_count


# COMMAND ----------

# MAGIC %md
# MAGIC ## Modeling Begins

# COMMAND ----------

# MAGIC %md
# MAGIC ### Logistic/Binary Classifier
# MAGIC

# COMMAND ----------

from pyspark.ml.classification import LogisticRegression
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.mllib.evaluation import MulticlassMetrics

# COMMAND ----------

# MAGIC %md
# MAGIC ### Base

# COMMAND ----------

# DBTITLE 1,Preddicted Vs Actual
lr = LogisticRegression() \
      .setMaxIter(100) \
      .setLabelCol("admit") \
      .setFeaturesCol("features") 

paramGrid=ParamGridBuilder() \
                   .addGrid(lr.regParam,[0.01,0.1,0.5]) \
                   .addGrid(lr.elasticNetParam,[0.0,0.5,1.0]) \
                   .build()

evaluator=BinaryClassificationEvaluator(
               labelCol="admit"
              ,rawPredictionCol="rawPrediction" 
              ,metricName="areaUnderPR"
          ) 
              
cv=CrossValidator() \
       .setEstimator(lr) \
       .setEvaluator(evaluator) \
       .setEstimatorParamMaps(paramGrid)

cvModel = cv.fit(vec_df)

best_model=cvModel.bestModel

predictions=best_model.transform(vec_df)
print("Model Intercept:",best_model.intercept)
print("Model Area Under PR:",evaluator.evaluate(predictions))
display(predictions.groupBy("prediction","admit").count())

# COMMAND ----------

predictionAndAdmits = predictions.select("prediction", "admit") \
    .rdd.map(lambda row: (float(row[0]), float(row[1])))
metrics = MulticlassMetrics(predictionAndAdmits)
print(f"Recall (label=1.0): {metrics.recall(1.0)}")
print(f"Precision (label=1.0): {metrics.precision(1.0)}")
print(f"F1-score (label=1.0): {metrics.fMeasure(1.0)}")

# COMMAND ----------

# DBTITLE 1,Look at Prediction Probabilities and explore 0.5
from pyspark.ml.feature import Bucketizer
from pyspark.sql.functions import element_at
from pyspark.ml.functions import vector_to_array

# Define your bin edges (splits)
splits = [0.00, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70 , 0.80, 0.90, 1.00]  
bucket_labels = {
    0.0: "<0.1",
    1.0: "0.1 to 0.2",
    2.0: "0.2 to 0.3",
    3.0: "0.3 to 0.4",
    4.0: "0.4 to  0.5",
    5.0: "0.5 to 0.6",
    6.0: "0.6 to 0.7",
    7.0: "0.7 to 0.8",
    8.0: "0.8 to 0.9",
    9.0: ">0.9"
}

# Extract probability of positive class (index 1)
predictions_with_prob = predictions.withColumn( "pos_prob"
                                               ,element_at(vector_to_array(col("probability")), 2))

bucketizer = Bucketizer(
    splits=splits,
    inputCol="pos_prob",
    outputCol="bucket_num"
)

bucketed_df = bucketizer.transform(predictions_with_prob)
# Map bucket index to label
labeled_df = bucketed_df.withColumn(
    "bucketLabel",
    when(col("bucket_num") == 0.0, bucket_labels[0.0])
    .when(col("bucket_num") == 1.0, bucket_labels[1.0])
    .when(col("bucket_num") == 2.0, bucket_labels[2.0])
    .when(col("bucket_num") == 3.0, bucket_labels[3.0])
    .when(col("bucket_num") == 4.0, bucket_labels[4.0])
    .when(col("bucket_num") == 5.0, bucket_labels[5.0])
    .when(col("bucket_num") == 6.0, bucket_labels[6.0])
    .when(col("bucket_num") == 7.0, bucket_labels[7.0])
    .when(col("bucket_num") == 8.0, bucket_labels[8.0])
    .when(col("bucket_num") == 9.0, bucket_labels[9.0])
    .when(col("bucket_num") == 10.0, bucket_labels[10.0])
)

histogram_df = (
    labeled_df.groupBy("bucketLabel","admit")
    .count()
    .orderBy("bucketLabel")
)

display(histogram_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Weighted

# COMMAND ----------

vec_wt_df=vec_df.withColumn("weight",when(col("admit")==1.0,1.0).otherwise(0.0))
lr = LogisticRegression() \
      .setMaxIter(100) \
      .setLabelCol("admit") \
      .setWeightCol("weight") \
      .setFeaturesCol("features") 

paramGrid=ParamGridBuilder() \
                   .addGrid(lr.regParam,[0.01,0.1,0.5]) \
                   .addGrid(lr.elasticNetParam,[0.0,0.5,1.0]) \
                   .build()

evaluator=BinaryClassificationEvaluator(
               labelCol="admit"
              ,rawPredictionCol="rawPrediction" 
              ,metricName="areaUnderPR"
          ) 
              
cv=CrossValidator() \
       .setEstimator(lr) \
       .setEvaluator(evaluator) \
       .setEstimatorParamMaps(paramGrid)

cvModel = cv.fit(vec_wt_df)

best_model=cvModel.bestModel

predictions=best_model.transform(vec_wt_df)
print("Model Intercept:",best_model.intercept)
print("Model Area Under PR:",evaluator.evaluate(predictions))
display(predictions.groupBy("prediction","admit").count())

# COMMAND ----------

predictionAndAdmits = predictions.select("prediction", "admit") \
    .rdd.map(lambda row: (float(row[0]), float(row[1])))
metrics = MulticlassMetrics(predictionAndAdmits)
print(f"Recall (label=1.0): {metrics.recall(1.0)}")
print(f"Precision (label=1.0): {metrics.precision(1.0)}")
print(f"F1-score (label=1.0): {metrics.fMeasure(1.0)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### XGBoost Classifier

# COMMAND ----------

from xgboost.spark import SparkXGBRegressor, SparkXGBClassifier 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Base

# COMMAND ----------

xgb_regressor = SparkXGBClassifier(
     #objective="binary:logistic"
     num_workers=4
    ,tree_method="hist"
    ,nthreads=1
    ,label_col="admit"
    ,features_col="features"
    ,missing=0.0
    ,seed=5
    ,max_depth=8
    ,learning_rate=0.05
    ,n_estimators=100
    ,verbosity=1
    ,eval_metric="logloss"
    ,minChildWeight=5     # Regularization
    ,subsample=0.8        # Row sampling
    ,colsampleBytree=0.8  # Feature sampling
)

# Tune
param_grid = ParamGridBuilder() \
    .addGrid(xgb_regressor.reg_lambda, [0.0, 0.5, 1.0]) \
    .addGrid(xgb_regressor.reg_alpha, [0.0, 0.5, 1.0]) \
    .build()

# Evaluate
evaluator=BinaryClassificationEvaluator(
               labelCol="admit"
              ,rawPredictionCol="rawPrediction" 
              ,metricName="areaUnderPR"
          ) 

#5FCV
cv = CrossValidator(estimator=xgb_regressor,
                    estimatorParamMaps=param_grid,
                    evaluator=evaluator,
                    numFolds=5,
                    parallelism=2)

xgb_model = cv.fit(vec_df)

bestModel = xgb_model.bestModel
predictions = bestModel.transform(vec_df)
print("Model Area Under PR:",evaluator.evaluate(predictions))
display(predictions.groupBy("prediction","admit").count())

# COMMAND ----------

predictionAndAdmits = predictions.select("prediction", "admit") \
    .rdd.map(lambda row: (float(row[0]), float(row[1])))
metrics = MulticlassMetrics(predictionAndAdmits)
print(f"Recall (label=1.0): {metrics.recall(1.0)}")
print(f"Precision (label=1.0): {metrics.precision(1.0)}")
print(f"F1-score (label=1.0): {metrics.fMeasure(1.0)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### XGBoost Classifier MAX DELTA STEP =1

# COMMAND ----------

xgb_regressor = SparkXGBClassifier(
     #objective="binary:logistic"
     num_workers=4
    ,tree_method="hist"
    ,nthreads=1
    ,label_col="admit"
    ,features_col="features"
    ,missing=0.0
    ,seed=5
    ,max_depth=8
    ,max_delta_step=1
    ,learning_rate=0.05
    ,n_estimators=100
    ,verbosity=1
    ,eval_metric="logloss"
    ,minChildWeight=5     # Regularization
    ,subsample=0.8        # Row sampling
    ,colsampleBytree=0.8  # Feature sampling
)

# Tune
param_grid = ParamGridBuilder() \
    .addGrid(xgb_regressor.reg_lambda, [0.0, 0.5, 1.0]) \
    .addGrid(xgb_regressor.reg_alpha, [0.0, 0.5, 1.0]) \
    .build()

# Evaluate
evaluator=BinaryClassificationEvaluator(
               labelCol="admit"
              ,rawPredictionCol="rawPrediction" 
              ,metricName="areaUnderPR"
          ) 

#5FCV
cv = CrossValidator(estimator=xgb_regressor,
                    estimatorParamMaps=param_grid,
                    evaluator=evaluator,
                    numFolds=5,
                    parallelism=2)

xgb_model = cv.fit(vec_df)

bestModel = xgb_model.bestModel
predictions = bestModel.transform(vec_df)
print("Model Area Under PR:",evaluator.evaluate(predictions))
display(predictions.groupBy("prediction","admit").count())

# COMMAND ----------

predictionAndAdmits = predictions.select("prediction", "admit") \
    .rdd.map(lambda row: (float(row[0]), float(row[1])))
metrics = MulticlassMetrics(predictionAndAdmits)
print(f"Recall (label=1.0): {metrics.recall(1.0)}")
print(f"Precision (label=1.0): {metrics.precision(1.0)}")
print(f"F1-score (label=1.0): {metrics.fMeasure(1.0)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### XGBoost Classifier MAX DELTA STEP = 1 & Scale Weight

# COMMAND ----------

xgb_regressor = SparkXGBClassifier(
     #objective="binary:logistic"
     scale_pos_weight=scale_weight
    ,num_workers=4
    ,tree_method="hist"
    ,nthreads=1
    ,label_col="admit"
    ,features_col="features"
    ,missing=0.0
    ,seed=5
    ,max_depth=8
    ,max_delta_step=1
    ,learning_rate=0.05
    ,n_estimators=100
    ,verbosity=1
    ,eval_metric="logloss"
    ,minChildWeight=5     # Regularization
    ,subsample=0.8        # Row sampling
    ,colsampleBytree=0.8  # Feature sampling
)

# Tune
param_grid = ParamGridBuilder() \
    .addGrid(xgb_regressor.reg_lambda, [0.0, 0.5, 1.0]) \
    .addGrid(xgb_regressor.reg_alpha, [0.0, 0.5, 1.0]) \
    .build()

# Evaluate
evaluator=BinaryClassificationEvaluator(
               labelCol="admit"
              ,rawPredictionCol="rawPrediction" 
              ,metricName="areaUnderPR"
          ) 

#5FCV
cv = CrossValidator(estimator=xgb_regressor,
                    estimatorParamMaps=param_grid,
                    evaluator=evaluator,
                    numFolds=5,
                    parallelism=2)

xgb_model = cv.fit(vec_df)

bestModel = xgb_model.bestModel
predictions = bestModel.transform(vec_df)
print("Model Area Under PR:",evaluator.evaluate(predictions))
display(predictions.groupBy("prediction","admit").count())

# COMMAND ----------

predictionAndAdmits = predictions.select("prediction", "admit") \
    .rdd.map(lambda row: (float(row[0]), float(row[1])))
metrics = MulticlassMetrics(predictionAndAdmits)
print(f"Recall (label=1.0): {metrics.recall(1.0)}")
print(f"Precision (label=1.0): {metrics.precision(1.0)}")
print(f"F1-score (label=1.0): {metrics.fMeasure(1.0)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Just Scale Weighted

# COMMAND ----------

xgb_regressor = SparkXGBClassifier(
     #objective="binary:logistic"
     scale_pos_weight=scale_weight
    ,num_workers=4
    ,tree_method="hist"
    ,nthreads=1
    ,label_col="admit"
    ,features_col="features"
    ,missing=0.0
    ,seed=5
    ,max_depth=8
    ,learning_rate=0.05
    ,n_estimators=100
    ,verbosity=1
    ,eval_metric="logloss"
    ,minChildWeight=5     # Regularization
    ,subsample=0.8        # Row sampling
    ,colsampleBytree=0.8  # Feature sampling
)

# Tune
param_grid = ParamGridBuilder() \
    .addGrid(xgb_regressor.reg_lambda, [0.0, 0.5, 1.0]) \
    .addGrid(xgb_regressor.reg_alpha, [0.0, 0.5, 1.0]) \
    .build()

# Evaluate
evaluator=BinaryClassificationEvaluator(
               labelCol="admit"
              ,rawPredictionCol="rawPrediction" 
              ,metricName="areaUnderPR"
          ) 

#5FCV
cv = CrossValidator(estimator=xgb_regressor,
                    estimatorParamMaps=param_grid,
                    evaluator=evaluator,
                    numFolds=5,
                    parallelism=2)

xgb_model = cv.fit(vec_df)

bestModel = xgb_model.bestModel
predictions = bestModel.transform(vec_df)
print("Model Area Under PR:",evaluator.evaluate(predictions))
display(predictions.groupBy("prediction","admit").count())

# COMMAND ----------

predictionAndAdmits = predictions.select("prediction", "admit") \
    .rdd.map(lambda row: (float(row[0]), float(row[1])))
metrics = MulticlassMetrics(predictionAndAdmits)
print(f"Recall (label=1.0): {metrics.recall(1.0)}")
print(f"Precision (label=1.0): {metrics.precision(1.0)}")
print(f"F1-score (label=1.0): {metrics.fMeasure(1.0)}")

# COMMAND ----------

# Get the underlying XGBoost Booster
booster = bestModel.get_booster()
feature_names = assembler.getInputCols()

# List of importance types
importance_types = [
    "weight", "gain", "cover", "total_gain", "total_cover"
]

# Collect importance scores for each type
importances = {}
for imp_type in importance_types:
    scores = booster.get_score(importance_type=imp_type)
    # Map XGBoost feature keys (e.g., 'f0', 'f1', ...) to feature names
    mapped = {feature_names[int(k[1:])]: v for k, v in scores.items()}
    importances[imp_type] = mapped

# Combine into a list of dicts for DataFrame creation
rows = []
for feat in feature_names:
    row = {"feature": feat}
    for imp_type in importance_types:
        row[imp_type] = importances[imp_type].get(feat, 0)
    rows.append(row)

# Create Spark DataFrame
importance_df = spark.createDataFrame(rows)
display(importance_df)