# Databricks notebook source
# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

# DBTITLE 1,Load Bad ID List
bad_dupes=spark.table("drop_dopps")

# COMMAND ----------

# DBTITLE 1,Demo
# 1.	Age: Patient is 18+ years old at the end of the lookback period.
# 2.	No End-of-Life Indicators: No evidence of death or hospice during the lookback period.
demo_pre=spark.read.parquet(f"{base_path}/demo_raw") \
               .join( bad_dupes
                     ,"ps_cci_member_id"
                     ,"left_anti") \
               .filter(col("pat_gender_cui_m").isin("CH000033","CH000034")) \
               .withColumn("sex",when(col("pat_gender_cui_m")=="CH000033","F").otherwise("M")) \
               .withColumn("dob",to_date(col("pat_dob"),"ddMMMyyyy")) \
               .withColumn("dod",to_date(col("pat_date_of_death"),"ddMMMyyyy")) \
               .withColumn("active_last",to_date(col("last_active_date"),"ddMMMyyyy")) \
               .withColumn( "active_order"
                           ,row_number().over(Window.partitionBy("ps_cci_member_id")
                                                    .orderBy(col("active_last").desc()))) \
               .filter(col("active_order") == 1) \
               .withColumn( "age"
                             ,floor(months_between(lit(startDate),to_date(col("dob"),"yyyyMMdd"))/12)) \
               .filter(col("age") >= 18) 

demo=demo_pre.select("ps_cci_member_id","age","dod") \
               .withColumn("dod_lookback",when(col("dod").between(startDate,endDate),1).otherwise(0)) \
               .withColumn("dod_outcome", when(col("dod").between(proStartDate, proEndDate), 1).otherwise(0)) \
               .select("ps_cci_member_id","age","dod_outcome","dod_lookback") \
               .distinct() \
               .filter(col("dod_lookback") == 0)  

print("Duplicate ID Check - Should be empty")
demo.groupBy("ps_cci_member_id").count().filter(col("count") > 1).show()          
#Hospice TBD

# COMMAND ----------

# 4.	Outcome Period Eligibility: 
#          o	Either 12 months of payer eligibility
#          o	OR (a positive response variable AND death in the outcome period).
# 5.	Minimum Payer Coverage: At least 1 month of payer eligibility in the outcome period.elig_include.write 
elig=spark.table("elig_include")

# COMMAND ----------

# DBTITLE 1,Combined
dem_elig=elig.join(demo,on='ps_cci_member_id',how='inner')
print(dem_elig.count())
display(dem_elig)

# COMMAND ----------

# DBTITLE 1,Elig Coverage
display(
    dem_elig.groupBy("months_tot").count())

# COMMAND ----------

dem_elig.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("ach_dem_elig")