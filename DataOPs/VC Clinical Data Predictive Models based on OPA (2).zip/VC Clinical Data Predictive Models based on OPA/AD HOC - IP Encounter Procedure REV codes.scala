// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")

// COMMAND ----------

// DBTITLE 1,Procedure Data Load
val procedure_raw=spark.read.parquet(f"$base_path/px_raw")

val px=procedure_raw.withColumn("px_date",to_date($"proc_date","ddMMMyyyy"))
                    .filter($"px_date".between(startDate,endDate))
                    .join( drop_dops
                          ,"ps_cci_member_id"
                          ,"left_anti")

// COMMAND ----------

px.columns

// COMMAND ----------

// DBTITLE 1,Encounter Data Load
val enc_map = spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv")

val disp_cat_map=spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_disp_cat.csv")

val enc_raw=spark.read.parquet(f"$base_path/enc_raw")
                 .withColumn("arrive_date",to_date($"enc_arrivaldate","ddMMMyyyy"))
                 .withColumn("admit_date",to_date($"enc_admitdate","ddMMMyyyy"))
                 .withColumn( "disch_date"
                              ,when(col( "discharge_date").isNull
                                        ,col("arrive_date"))
                              .otherwise(to_date($"discharge_date","ddMMMyyyy")))
                 .join( drop_dops
                       ,"ps_cci_member_id"
                       ,"left_anti")

val enc_prep=enc_raw.filter($"arrive_date".between(startDate,endDate))
                    .join(enc_map,enc_raw("hts_patient_type_cui")===enc_map("CUI_CODE"),"left")
                    .join(disp_cat_map,enc_raw("discharge_disp_m")===disp_cat_map("Concept_CUI"),"left")

// COMMAND ----------

enc_prep.columns

// COMMAND ----------

print(enc_prep.filter($"hts_patient_type_cui"===lit("CH000106"))
          .filter($"disch_date">=$"arrive_date")
          .count())

// COMMAND ----------

// DBTITLE 1,Early LOS
display(
  enc_prep.filter($"hts_patient_type_cui"===lit("CH000106"))
          .filter($"disch_date">=$"arrive_date")
          .withColumn("LOS",datediff(col("disch_date"),col("arrive_date")))
          .groupBy("LOS").count()
  )

// COMMAND ----------

// DBTITLE 1,R&B Codes
//  '0100', -- All inclusive room & board
//  '0110', '0111', '0112', '0113', -- Semi-private
//  '0120', '0121', '0122', -- Private
//  '0130', '0131', '0132', -- 3-bed
//  '0140', '0141', '0142', -- 4-bed
//  '0150', '0151', -- Ward
//  '0160', '0161', -- Detox
//  '0200', '0210'  -- ICU, CCU

val ip_rnb=px.filter($"mappedcode_nodecm".isin("0100","0110","0111","0112","0113","0120","0121","0122","0130","0131","0132","0140","0141","0142","0150","0151","0160","0161","0200","0210"))
               .select("ps_cci_member_id","px_date","mappedcode_nodecm")
               .distinct()
 
 print(ip_rnb.count())

// COMMAND ----------

// DBTITLE 1,IP Admits
val ip_admits=enc_prep.filter($"hts_patient_type_cui"===lit("CH000106"))
                      .filter($"disch_date">=$"arrive_date")
                      .withColumn("dt_diff",datediff(col("disch_date"),col("arrive_date")))
                      .filter(!($"dt_diff"===lit(0) && $"enc_facilityid".isNull))
                      .withColumn("LOS",when($"dt_diff"===lit(0),lit(1)).otherwise(col("dt_diff")))
                      .select( $"ps_cci_member_id"
                              ,$"enc_enc_id"
                              ,$"enc_facilityid"
                              ,$"Label"
                              ,$"arrive_date"
                              ,$"disch_date"
                              ,$"LOS"
                              ,$"Concept Name")
println(ip_admits.count())                      

// COMMAND ----------

// DBTITLE 1,LOS - What are same-day admits?
display(
  ip_admits.groupBy("LOS").count()
)

// COMMAND ----------

// DBTITLE 1,Encounter contains R&B Code?
val admits_rnb=ip_admits.join(ip_rnb,Seq("ps_cci_member_id"),"left")
                        .filter($"px_date">=$"arrive_date" && $"px_date"<=$"disch_date")
println(admits_rnb.count())
display( admits_rnb )

// COMMAND ----------

display(
  admits_rnb.orderBy("arrive_date","disch_date").filter($"ps_cci_member_id"===lit("123059366122019"))
  )

// COMMAND ----------

import org.apache.spark.sql.expressions.Window

val id="ps_cci_member_id"
val start_date="arrive_date"
val end_date="disch_date"

// Sort by start_date
val windowSpec=Window.partitionBy(id)
                     .orderBy(start_date)

// Create a lag column to compare with previous end_date
val dfWithLag=admits_rnb.withColumn( "prev_end"
                                    ,lag(end_date,1)
                         .over(windowSpec))

// Define a flag to start a new group when there's no overlap
val dfWithFlag=dfWithLag.withColumn( "new_group"
                                    ,when(col("prev_end").isNull || col(start_date) > col("prev_end") + expr("INTERVAL 1 DAY"), 1)
                        .otherwise(0))

// Cumulative sum to assign group ids
val dfWithGroupId=dfWithFlag.withColumn( "group_id"
                                         ,sum("new_group").over(windowSpec.rowsBetween(Window.unboundedPreceding, 0)))

// Aggregate spans by group
val final_spans=dfWithGroupId.groupBy( id,"group_id")
  .agg( min(start_date).as("span_start")
       ,max(end_date).as("span_end"))
  .orderBy( id
           ,"span_start")
  .withColumn("dt_diff",datediff(col("span_end"),col("span_start")))
  .withColumn("LOS",when($"dt_diff"===lit(0),lit(1)).otherwise(col("dt_diff")))   

println(final_spans.count())

// COMMAND ----------

display(final_spans)

// COMMAND ----------

display(final_spans.groupBy("LOS").count())