// Databricks notebook source
// MAGIC %md
// MAGIC # Support Specifications: Insurance Eligibility Data Processing Notebook
// MAGIC
// MAGIC ## Purpose
// MAGIC This notebook ingests, cleans, validates, and prepares insurance eligibility data for downstream analytics or modeling.
// MAGIC
// MAGIC ## Supported Features
// MAGIC
// MAGIC - **Configuration Management:** Imports shared variables and configuration from an external notebook for consistent file paths and parameters.
// MAGIC - **Data Ingestion:** Reads Parquet files for both doppleganger member IDs and raw eligibility data.
// MAGIC - **Data Cleaning & Transformation:**
// MAGIC   - Flags missing or invalid enrollment and insurance dates.
// MAGIC   - Converts string date columns (format: `ddMMMyyyy`) to date types.
// MAGIC - **Data Validation:**
// MAGIC   - Identifies and counts records with invalid date ranges (end date before start date).
// MAGIC   - Summarizes missing data by source and flag.
// MAGIC - **Filtering & Preparation:**
// MAGIC   - Filters for a specific data source (e.g., `int_claim_member`).
// MAGIC   - Excludes doppleganger member IDs.
// MAGIC   - Retains only records with valid date ranges.
// MAGIC   - Normalizes eligibility periods to full months.
// MAGIC - **Output:** Produces cleaned DataFrames and summary statistics for data quality assessment.
// MAGIC
// MAGIC ## Inputs
// MAGIC
// MAGIC - Configuration notebook (shared variables, file paths).
// MAGIC - Parquet file: Doppleganger member IDs.
// MAGIC - Parquet file: Raw insurance eligibility data.
// MAGIC
// MAGIC ## Outputs
// MAGIC
// MAGIC - Cleaned and validated eligibility DataFrames.
// MAGIC - Aggregated data quality summaries.
// MAGIC
// MAGIC ## Business Rules
// MAGIC
// MAGIC - Exclude records with missing or invalid date ranges.
// MAGIC - Exclude doppleganger members.
// MAGIC - Normalize eligibility periods to whole months.
// MAGIC
// MAGIC ## Assumptions
// MAGIC
// MAGIC - All input files are Parquet and accessible via configured paths.
// MAGIC - Date columns are in `ddMMMyyyy` string format.
// MAGIC
// MAGIC ## Limitations
// MAGIC
// MAGIC - Only processes one data source (`int_claim_member`) in final extraction.
// MAGIC - Does not perform downstream analytics or modeling.
// MAGIC
// MAGIC ## Extensibility
// MAGIC
// MAGIC - Additional sources or business rules can be added by modifying filtering and transformation steps.

// COMMAND ----------

// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")

// COMMAND ----------

val raw_elig=spark.read.parquet(f"$base_path/ins_raw")  
                      .withColumn("eff_beg_miss",when($"ins_enrollstart_date".isNull,lit(1)).otherwise(lit(0)))
                      .withColumn("eff_end_miss",when($"ins_enrollend_date".isNull,lit(1)).otherwise(lit(0)))
                      .withColumn("ins_date_miss",when($"ins_date".isNull,lit(1)).otherwise(lit(0)))
                      .withColumn("eff_beg_raw",to_date($"ins_enrollstart_date","ddMMMyyyy"))
                      .withColumn("eff_end_raw",to_date($"ins_enrollend_date","ddMMMyyyy"))
                      .withColumn("elg_date",to_date($"ins_date","ddMMMyyyy"))
                      .withColumn("updt_date",to_date($"update_date","ddMMMyyyy"))

// COMMAND ----------

display(raw_elig.groupBy("eff_beg_raw","eff_end_raw").count())

// COMMAND ----------

// DBTITLE 1,Negative Ranges
//display(
  raw_elig.filter($"eff_end_raw"<$"eff_beg_raw").count()
//)

// COMMAND ----------

display(
  raw_elig.groupBy( "ins_emr_source"
                   ,"eff_beg_miss"
                   ,"eff_end_miss"
                   ,"ins_date_miss").count()
  )

// COMMAND ----------

// Any eligibility in a month rounds to whole month
val payer_elig=raw_elig.filter($"ins_emr_source"===lit("int_claim_member"))
                       .join( drop_dops
                             ,"ps_cci_member_id"
                             ,"left_anti")
                       .withColumn("eff_beg", trunc($"eff_beg_raw","month"))
                       .withColumn("eff_end", last_day($"eff_end_raw"))
                       .filter($"updt_date">=proEndDate)

//payer_elig.write.mode(SaveMode.Overwrite).parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/payer_elig/")

// COMMAND ----------

display(payer_elig.groupBy("eff_beg_raw","eff_end_raw").count())

// COMMAND ----------

payer_elig.select("ps_cci_member_id").distinct().count()

// COMMAND ----------

payer_elig.filter(($"eff_beg_miss"===0) && ($"eff_end_miss"===0))
        .agg( min("eff_beg").as("min_beg")
             ,max("eff_beg").as("max_beg")
             ,min("eff_end").as("min_end")
             ,max("eff_end").as("max_end")).show()

// COMMAND ----------

import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql.expressions.Window

val beg_col="eff_beg"
val end_col="eff_end"
val pat_id="ps_cci_member_id"

val gapToleranceDays = 1

// Sort by member and begin date
val w = Window.partitionBy(pat_id).orderBy(beg_col)

// Track the running maximum EndDate so far
val dfWithRunningEnd = payer_elig
  .withColumn("PrevEndDate", F.lag(end_col, 1).over(w))
  .withColumn("RunningMaxEnd",
    F.when($"PrevEndDate".isNull, col(end_col))
     .otherwise(F.greatest(col(end_col),
       F.max(end_col).over(
         w.rowsBetween(Window.unboundedPreceding, -1)
       ))))

// Calculate the gap between this begin and the running maximum end so far
val dfWithGroup = dfWithRunningEnd
  .withColumn("GapDays",F.datediff(col(beg_col), $"RunningMaxEnd"))
  .withColumn("NewGroup",F.when($"RunningMaxEnd".isNull || $"GapDays" > gapToleranceDays, 1).otherwise(0))
  .withColumn("GroupID", F.sum("NewGroup").over(w))

// Combine spans per group
val combinedSpans = dfWithGroup
  .groupBy(pat_id,"GroupID")
  .agg(F.min(beg_col).as("SpanBegin"),F.max(end_col).as("SpanEnd"))
  .orderBy(pat_id, "SpanBegin")

// COMMAND ----------

val pat_spans=combinedSpans.withColumn( "retro_beg"
                                        ,when( $"SpanBegin"<=lit(endDate) && $"SpanEnd">=lit(startDate)
                                              ,when( $"SpanBegin"<lit(startDate)
                                                    ,lit(startDate))
                                               .otherwise(col("SpanBegin")))
                                        .otherwise(lit(null)))
                           .withColumn( "retro_end"
                                       ,when( $"SpanBegin"<=lit(endDate) && $"SpanEnd">=lit(startDate)
                                              ,when( $"SpanEnd">lit(endDate)
                                                    ,lit(endDate))
                                               .otherwise(col("SpanEnd")))
                                        .otherwise(lit(null)))
                           .withColumn( "prosp_beg"
                                        ,when( $"SpanBegin"<=lit(proEndDate) && $"SpanEnd">=lit(proStartDate)
                                              ,when( $"SpanBegin"<lit(proStartDate)
                                                    ,lit(proStartDate))
                                               .otherwise(col("SpanBegin")))
                                        .otherwise(lit(null)))
                           .withColumn( "prosp_end"
                                       ,when( $"SpanBegin"<=lit(proEndDate) && $"SpanEnd">=lit(proStartDate)
                                              ,when( $"SpanEnd">lit(proEndDate)
                                                    ,lit(proEndDate))
                                               .otherwise(col("SpanEnd")))
                                        .otherwise(lit(null)))             
                           .withColumn("ret_months",(month($"retro_end")-month($"retro_beg"))+1)
                           .withColumn("pro_months",(month($"prosp_end")-month($"prosp_beg"))+1)

// COMMAND ----------

display(pat_spans.orderBy("ps_cci_member_id","GroupId"))
//.filter(col("ps_cci_member_id")===lit(12305416068486L)))

// COMMAND ----------

pat_spans.groupBy(pat_id).count().filter($"count">1).show()

// COMMAND ----------

val retro_pats_idx=pat_spans.filter($"ret_months".isNotNull).select(col(pat_id),$"ret_months").distinct()
retro_pats_idx.write
         .mode("overwrite")
         .parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/retro_pats_idx")

val prosp_pats_idx=pat_spans.filter($"pro_months".isNotNull).select(col(pat_id),$"pro_months").distinct()
prosp_pats_idx.write
         .mode("overwrite")
         .parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/prosp_pats_idx")

// COMMAND ----------

display( pat_spans.groupBy("ps_cci_member_id").agg( sum("ret_months").as("months_tot")
                                                   ,count("*").as("row_ct")) 
                  .groupBy("months_tot").count().orderBy("months_tot")                                 

  )

// COMMAND ----------

display( pat_spans.groupBy("ps_cci_member_id").agg( sum("pro_months").as("months_tot")
                                                   ,count("*").as("row_ct")) 
                  .groupBy("months_tot").count().orderBy("months_tot")                                 

  )

// COMMAND ----------

display(pat_spans.groupBy("prosp_beg","prosp_end").count())

// COMMAND ----------

display(raw_elig.groupBy("eff_beg_raw","eff_end_raw").count())

// COMMAND ----------

// Get all ids for folks with 3 months of retro
val Q1only=pat_spans.groupBy("ps_cci_member_id").agg( sum("pro_months").as("months_tot")
                                                   ,count("*").as("row_ct")) 
                  .filter($"months_tot"===lit(3))  

// Examine their raw eligg rows
val q1_raw=Q1only.join( raw_elig.filter($"ins_emr_source"===lit("int_claim_member"))
                        ,Seq("ps_cci_member_id")
                        ,"left")
                  .orderBy("ps_cci_member_id")      

display(q1_raw.select("ps_cci_member_id","ins_enrollend_date","ins_enrollstart_date","update_date"))

// COMMAND ----------

val elig_include=pat_spans.groupBy("ps_cci_member_id")
                          .agg( sum("pro_months").as("months_tot")
                               ,count("*").as("row_ct"))
                          .filter(!(col("months_tot").isNull))

elig_include.count()
display(elig_include)

// COMMAND ----------

elig_include.write 
    .format("delta")   // You can also use "parquet", "csv", etc.
    .mode("overwrite")  // Options: overwrite, append, ignore, error (default)
    .saveAsTable("elig_include")

// COMMAND ----------

// DBTITLE 1,QA
display(payer_elig.select("ins_groupid").distinct())

// COMMAND ----------

// DBTITLE 1,QA
display(payer_elig.select("ps_cci_member_id","ins_groupid").distinct().groupBy("ins_groupid").count())

// COMMAND ----------

