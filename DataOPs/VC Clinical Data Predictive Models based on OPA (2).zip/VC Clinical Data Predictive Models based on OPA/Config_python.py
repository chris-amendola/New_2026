# Databricks notebook source
# Replace these with your actual values
storage_account_name = "ovemldev"
container_name = "nonuc"
access_key = "1KGe1jTkEqTACFbbz2ghv1PMpJExBtBfow2o7zgNJa06yvGJokXJAJXHASAb+rWO/MbyQWdf2XiS+AStIPHPCA=="

# Set Spark configuration to use the access key
spark.conf.set(f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net", access_key)

# COMMAND ----------

storage_account_name = "ovemldev"
container_name = "nonuc"
# Define the path to the container
adls_path = f"abfss://$container_name@$storage_account_name.dfs.core.windows.net/"

# COMMAND ----------

from pyspark.sql.functions import date_format, current_date, when, log, col, lit, sum, to_date, mean, round, floor, months_between, row_number, regexp_replace, length, lag, expr, min, max, datediff, greatest, concat, abs
from pyspark.sql import types, functions, Window
from datetime import datetime

# COMMAND ----------

root_src="dbfs:/mnt/jvmlshare"
base_path=f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2"

startDate=datetime.strptime('01/01/2023', "%m/%d/%Y").date()
endDate=datetime.strptime('12/31/2023', "%m/%d/%Y").date()

proStartDate=datetime.strptime('01/01/2024', "%m/%d/%Y").date()
proEndDate=datetime.strptime('12/31/2024', "%m/%d/%Y").date()
print(startDate)

# COMMAND ----------

# MAGIC %fs
# MAGIC ls 

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/mnt/jvmlshare