# Databricks notebook source
# MAGIC %md
# MAGIC ## Objective
# MAGIC This notebook implements feature engineering, model training, and analysis for capture-recapture estimation using Spark and XGBoost.
# MAGIC
# MAGIC ## Workflow Overview
# MAGIC 1. **Data Loading**: Loads the `cap_recap` table into a Spark DataFrame.
# MAGIC 2. **Feature Engineering**:
# MAGIC      - Creates binary and count-based features (e.g., `hi_int_*`, `all`, `three_a`, `pos_ct`, `xfrm_ct`).
# MAGIC      - Generates pairwise interaction features between main effects.
# MAGIC      - Assembles selected features into a single vector column for modeling.
# MAGIC 3. **Model Training**:
# MAGIC      - Trains a Poisson XGBoost regressor using SparkXGBRegressor.
# MAGIC      - Performs hyperparameter tuning with cross-validation.
# MAGIC 4. **Prediction & Estimation**:
# MAGIC      - Predicts counts for observed and unobserved histories.
# MAGIC      - Estimates total population size.
# MAGIC 5. **Model Evaluation**:
# MAGIC      - Computes regression metrics (RMSE, MAE, R², MSE, Variance).
# MAGIC      - Analyzes residuals and feature importance.
# MAGIC  
# MAGIC ## Key Variables
# MAGIC - `cap_matrix`: Input DataFrame with capture histories.
# MAGIC - `feature_cols`, `intx_cols`, `main_effects`: Lists of feature and interaction column names.
# MAGIC - `assembler`: VectorAssembler for feature vectorization.
# MAGIC - `cap_matrix_vec`: DataFrame with feature vectors.
# MAGIC - `xgb_regressor`, `xgb_model`, `bestModel`: XGBoost model objects.
# MAGIC - `predictions`: DataFrame with model predictions.
# MAGIC  
# MAGIC ##  Outputs
# MAGIC - Transformed feature table: `cap_recap`
# MAGIC - Model evaluation metrics and feature importances
# MAGIC - Estimated unobserved count and total population size
# MAGIC - Residual analysis plots

# COMMAND ----------

# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

cap_matrix=spark.table("cap_recap")

# COMMAND ----------

# DBTITLE 1,Feature Work
# Specifications Summary:
# - Imports feature engineering and math utilities.
# - Creates binary and count-based feature columns in cap_matrix.
# - Defines main_effects and interaction columns for modeling.
# - Generates all pairwise interaction features between main_effects.
# - Saves the transformed DataFrame to the "cap_recap" table.
# - Manually sets intx_cols to specific interaction terms.
# - Prints selected features and their count.
# - Assembles features into a single vector column "features" using VectorAssembler.
# - Transforms and orders the DataFrame for modeling.

from pyspark.ml.feature import VectorAssembler, Interaction
from math import exp
from pyspark.sql.functions import sqrt
from itertools import combinations

# Assemble features
# Define Feature Columns
cap_matrix=cap_matrix.withColumn("hi_int_enc",when(col("idx_enc")==1,0).otherwise(1)) \
                      .withColumn("hi_int_rx",when(col("idx_rx")==1,0).otherwise(1)) \
                      .withColumn("hi_int_lab",when(col("idx_lab")==1,0).otherwise(1)) \
                      .withColumn("hi_int_dx",when(col("idx_dx")==1,1).otherwise(0)) \
                      .withColumn("hi_int_px",when(col("idx_dx")==1,1).otherwise(0)) \
                      .withColumn("hi_int_obs",when(col("idx_obs")==1,1).otherwise(0))
#Create an all occcasions marker
cap_matrix=cap_matrix.withColumn( "all"
                                 ,when((col("idx_dx")==1) & (col("idx_enc")==1) & (col("idx_obs")==1) & (col("idx_px")==1) & (col("idx_rx")==1) & (col("idx_lab")==1), 1).otherwise(0)
                                 ).withColumn("three_a"
                                 ,when((col("idx_dx")==1) & (col("idx_obs")==1) & (col("idx_px")==1), 1).otherwise(0)
                                 ).withColumn("pos_ct",(col("idx_dx")+col("idx_enc")+col("idx_obs")+col("idx_px")+col("idx_rx")+col("idx_lab"))
                                 ).withColumn("xfrm_ct",col("count")**.25)

feature_cols = ["idx_dx","idx_enc", "idx_obs", "idx_px", "idx_rx", "idx_lab"]
feature_cols = ["all"]
intensity_cols = ["hi_int_enc","hi_int_rx","hi_int_lab","hi_int_dx","hi_int_px","hi_int_obs"]
intx_cols=[]

main_effects=feature_cols #+ intensity_cols
#main_effects=intensity_cols

df=cap_matrix

# All pairwise interactions
from itertools import combinations
for (c1,c2) in combinations((main_effects), 2):
    intx_cols.append(f"{c1}*{c2}")
    df=df.withColumn(f"{c1}*{c2}", df[c1] * df[c2])

df.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("cap_recap")

#: Use only intensity interactions
intx_cols=[ 'idx_dx*all'
           ,'idx_px*all'
           ,'idx_rx*all'
           ,'idx_lab*all'
           ,'idx_enc*all'
           ,'idx_obs*all','all']
intx_cols=["all"]
intx_cols=[ 'idx_dx*hi_int_dx'
           ,'idx_px*hi_int_px'
           ,'idx_obs*hi_int_obs'
           ]

print(f"Selected Features: {main_effects+intx_cols}")
print(f"Number: {len(main_effects+intx_cols)}")
assembler=VectorAssembler( inputCols=main_effects+intx_cols
                          ,outputCol="features")

cap_matrix_vec=assembler.transform(df.orderBy("count"))

#display(cap_matrix_vec)

# COMMAND ----------

# DBTITLE 1,Model Train
from xgboost import XGBRegressor
from xgboost.spark import SparkXGBRegressor
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator

xgb_regressor = SparkXGBRegressor(
     objective="count:poisson"
    ,num_workers=4
    ,tree_method="hist"
    ,nthreads=1
    ,label_col="count"
    ,features_col="features"
    ,missing=0.0
    ,seed=5
    ,max_depth=8
    ,learning_rate=0.05
    ,n_estimators=100
    ,verbosity=1
    ,eval_metric="poisson-nloglik"
    ,minChildWeight=5     # Regularization
    ,subsample=0.8        # Row sampling
    ,colsampleBytree=0.8  # Feature sampling
)

# Tune
## Version 1
#param_grid = ParamGridBuilder() \
#    .addGrid(xgb_regressor.max_depth, [3, 5]) \
#    .addGrid(xgb_regressor.learning_rate, [ 0.2, 0.3]) \
#    .addGrid(xgb_regressor.n_estimators, [50, 100]) \
#    .addGrid(xgb_regressor.reg_lambda, [0.0, 1.0]) \
#    .addGrid(xgb_regressor.reg_alpha, [0.0, 1.0]) \
#    .build()
## Version 2
param_grid = ParamGridBuilder() \
    .addGrid(xgb_regressor.reg_lambda, [0.0, 0.5, 1.0]) \
    .addGrid(xgb_regressor.reg_alpha, [0.0, 0.5, 1.0]) \
    .build()


# Evaluate
evaluator = RegressionEvaluator( labelCol="count"
                                ,predictionCol="prediction"
                                ,metricName="mae")  

#5FCV
cv = CrossValidator(estimator=xgb_regressor,
                    estimatorParamMaps=param_grid,
                    evaluator=evaluator,
                    numFolds=5,
                    parallelism=2)

xgb_model = cv.fit(cap_matrix_vec)

bestModel = xgb_model.bestModel
predictions = bestModel.transform(cap_matrix_vec)
print(assembler.getInputCols())

# COMMAND ----------

# DBTITLE 1,Post Train Analysis
# Make predictions
predictions = bestModel.transform(cap_matrix_vec)
#predictions.show()

# Evaluate the model
evaluator_rmse = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="rmse")
evaluator_r2 = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="r2")
evaluator_mae = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="mae")
evaluator_mse = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="mse")
evaluator_var = RegressionEvaluator(labelCol="count", predictionCol="prediction", metricName="var")

rmse = evaluator_rmse.evaluate(predictions)
r2 = evaluator_r2.evaluate(predictions)
mae = evaluator_mae.evaluate(predictions)
mse = evaluator_mse.evaluate(predictions)
var = evaluator_var.evaluate(predictions)


# Print metrics
print(f"Root Mean Squared Error (RMSE): {rmse}")
print(f"R Squared (R²): {r2}")
print(f"Mean Absolute Error (MAE): {mae}")
print(f"Mean Squared Error (MSE): {mse}")
print(f"Variance Explained: {var}")
print(assembler.getInputCols())

# COMMAND ----------

# DBTITLE 1,Unobserved Estimation
from pyspark.sql.functions import exp
# Predict the unobserved count (0, 0 history)
# Create a DataFrame for the unobserved history
unobserved_data = [(0.0,) * len(main_effects+intx_cols)]
unobserved_df = spark.createDataFrame(unobserved_data, main_effects+intx_cols)
assembled_unobserved_df = assembler.transform(unobserved_df)
print(assembler.getInputCols())
#assembled_unobserved_df.show()

# Use the model to predict the expected count for the (0, 0) history
predicted_unobserved_df = bestModel.transform(assembled_unobserved_df)
#predicted_unobserved_df.show()
predicted_unobserved_count = predicted_unobserved_df.select(col("prediction").alias("estimated_count")).collect()[0]["estimated_count"]

print(f"Estimated unobserved count: {predicted_unobserved_count}")

# Estimate the total population size
total_observed_count = cap_matrix_vec.agg(sum("count")).collect()[0][0]
estimated_total_population = total_observed_count + predicted_unobserved_count

print(f"Total observed count: {total_observed_count}")
print(f"Estimated total population size: {estimated_total_population}")

# COMMAND ----------

# DBTITLE 1,Residual Analysis 1
predictions_with_residuals = predictions.withColumn(
    "residual", col("count") - col("prediction")
)
residual_stats = predictions_with_residuals.select("residual").describe()
residual_stats.show()

# COMMAND ----------

# DBTITLE 1,Residual Analysis 2
import matplotlib.pyplot as plt

# Collect residuals
residuals = predictions_with_residuals.select("residual").rdd.flatMap(lambda x: x).collect()

# Plot histogram
plt.hist(residuals, bins=30, edgecolor='k')
plt.title("Residuals Distribution")
plt.xlabel("Residual")
plt.ylabel("Frequency")
plt.show()

# COMMAND ----------

# DBTITLE 1,Residual Analysis 3
# Collect predictions and residuals
predicted_residuals = predictions_with_residuals.select("prediction", "residual").rdd.map(lambda row: (row[0], row[1])).collect()

# Separate predictions and residuals
predictions, residuals = zip(*predicted_residuals)

# Scatter plot
plt.scatter(predictions, residuals, alpha=0.5)
plt.axhline(y=0, color='r', linestyle='--')
plt.title("Residuals vs. Predicted Values")
plt.xlabel("Predicted Values")
plt.ylabel("Residuals")
plt.show()

# COMMAND ----------

# DBTITLE 1,Feature Importance
# Extract feature importance
booster = bestModel.get_booster()
feature_importance = booster.get_score(importance_type='gain')
print(feature_importance)
# Map feature importance to feature names
feature_mapping = assembler.getInputCols()
print(assembler.getInputCols())
mapped_importance = {feature_mapping[int(k[1:])]: v for k, v in feature_importance.items()}

# Display feature importance
print("Feature Importance (Gain):")
for feature, importance in mapped_importance.items():
    print(f"{feature}: {importance}")

# COMMAND ----------

predicted_residuals

# COMMAND ----------

