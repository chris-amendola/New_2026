# Databricks notebook source
# DBTITLE 1,Medications
imap_dcc = spark.read.option("delimiter", "|").csv(f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/IMAP_DCC.txt", header=True)
dcc_to_pcc = imap_dcc.select("DCC", "PCC").dropna().filter(col("PCC") != "999")
combine_df = med_df.join(broadcast(dcc_to_pcc), med_data.rxpat_dcc == dcc_to_pcc.DCC, how="inner")

# COMMAND ----------

# DBTITLE 1,Conditions
