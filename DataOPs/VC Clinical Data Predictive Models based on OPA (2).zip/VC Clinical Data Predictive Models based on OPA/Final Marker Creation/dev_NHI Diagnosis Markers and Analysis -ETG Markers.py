# Databricks notebook source
# MAGIC %md
# MAGIC Importing Configurations

# COMMAND ----------

# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

# COMMAND ----------


from datetime import date
startDate = date(2023, 1, 1)
endDate = date(2023, 12, 31)
proStartDate = date(2024, 1, 1)
proEndDate = date(2024, 12, 31)


# COMMAND ----------

# MAGIC %md
# MAGIC Dropping Doppleganger Records

# COMMAND ----------

path = f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers"

# COMMAND ----------


drop_dops = spark.read.parquet(path)

# COMMAND ----------

drop_dops.display()


# COMMAND ----------

drop_dops.count()

# COMMAND ----------

# MAGIC %md
# MAGIC Importing ETG Mapping and filtering for 3000 ruleid's

# COMMAND ----------

from pyspark.sql.functions import col
df_desc = (
    spark.read
    .option("header", True)
    .option("inferSchema", True)
    .option("delimiter", "|")
    .csv("dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/IMAP_CLINMARK_DEF (3).txt")
    .filter((col("RULEID") >= 3000) & (col("RULEID") <= 3999))
)
display(df_desc)

# COMMAND ----------

df = (
    spark.read
    .option("header", True)  # <-- Change to True
    .option("inferSchema", True)
    .option("delimiter", "|")
    .csv("dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/IMAP_CLINMARK_CODES.txt")
    .filter((col("RULEID").cast("bigint") >= 3000) & (col("RULEID").cast("bigint") <= 3999))
)
display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC Joining the with ETG Code with Description

# COMMAND ----------

df_joined = df.join(df_desc, df["RULEID"] == df_desc["RULEID"], how="left") \
              .select(df['RULEID'], 'CODE', 'SHORTDESC')
display(df_joined)

# COMMAND ----------

from pyspark.sql.functions import split, col

df_split = df_joined.withColumn(
    "ETG-CODE",
    split(col("SHORTDESC"), "-").getItem(0)
).withColumn(
    "DESCRIPTION",
    split(col("SHORTDESC"), "-").getItem(1)
)

display(df_split)

# COMMAND ----------

from pyspark.sql.functions import col, concat, substring, lit

df_marker = df_split.withColumn(
    "MARKER",
    concat(substring(col("DESCRIPTION"), 1, 4), lit("_"), col("ETG-CODE"))
)

display(df_marker)

# COMMAND ----------

# MAGIC %md
# MAGIC Creating Marker column with CON_ETG(6 digit code)

# COMMAND ----------

df_marker= df_marker.select("CODE", "MARKER")
display(df_marker)

# COMMAND ----------

# MAGIC %md
# MAGIC Importing raw diagnosis data 

# COMMAND ----------

raw_dx = spark.read.parquet(f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/dx_24_raw") \
                .union(spark.read.parquet(f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/dx_23_raw"))

# COMMAND ----------

raw_dx.display()

# COMMAND ----------

from pyspark.sql.functions import to_date, col, regexp_replace, length

dx = raw_dx.withColumn("dx_date", to_date(col("diag_date"), "ddMMMyyyy")) \
    .filter(col("dx_date").between(startDate, endDate)) \
    .filter(col("diag_codetype") == "ICD10") \
    .filter((col("prim_diagnosis_flg") == 1) | (col("problemlist_flag") == "Y")) \
    .withColumn("DX_pre", regexp_replace(col("mappeddiagnosis"), r"\.", "")) \
    .filter(length(col("DX_pre")) > 3) \
    .join(drop_dops, on="ps_cci_member_id", how="left_anti")


# COMMAND ----------

dx.count()

# COMMAND ----------

dx.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Joining etg mapping with diagnosis data of members

# COMMAND ----------

# Join dx with ETG_map on DX_pre and  Code
etg_dx = dx.join(df_marker, dx["DX_pre"] == df_marker["Code"])

# Select and deduplicate relevant columns
clin_pat_conds = etg_dx.select(
    "ps_cci_member_id",
    "MARKER"
).distinct()
clin_pat_conds.display()

# COMMAND ----------

from pyspark.sql.functions import lit

clin_condtion_marks = clin_pat_conds.select("ps_cci_member_id", "marker") \
                                    .withColumn("value", lit(1))

# COMMAND ----------

# MAGIC %md
# MAGIC Displaying final markers

# COMMAND ----------

clin_condtion_marks.orderBy('ps_cci_member_id', ascending=True).limit(10000).display()


# COMMAND ----------

clin_condtion_marks.count()

# COMMAND ----------

# Drop the existing table if you do not need its data
spark.sql("DROP TABLE IF EXISTS MARKERS.condition")

# Now write your DataFrame as a new table
clin_condtion_marks.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("MARKERS.condition")