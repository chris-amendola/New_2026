# Databricks notebook source
# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

raw_demo=spark.read.parquet(f"{base_path}/demo_raw") \
              .withColumn("dob",to_date(col("pat_dob"),"ddMMMyyyy")) \
              .withColumn("dod",to_date(col("pat_date_of_death"),"ddMMMyyyy")) \
              .withColumn("active_last",to_date(col("last_active_date"),"ddMMMyyyy"))

# COMMAND ----------

interval=5
demo=raw_demo.filter(((col("dod")>=endDate) | col("dod").isNull()) & ~(col("dob").isNull())) \
             .filter(col("pat_gender_cui_m").isin("CH000033","CH000034")) \
             .withColumn("sex",when(col("pat_gender_cui_m")=="CH000033","F").otherwise("M")) \
             .withColumn( "age_calc"
                         ,floor(months_between(lit(startDate),to_date(col("dob"),"yyyyMMdd"))/12)) \
             .withColumn("age",when(col("age_calc")>85,lit(85)).otherwise(col("age_calc"))) \
             .withColumn("range",col("age")-(col("age")%interval)) \
             .withColumn("marker",concat(lit("D_"),col("sex"),col("range"),lit("_"),col("range")+interval)) \
             .filter((col("age")>=0) & (col("age")<=102)) \
             .withColumn("active_last",to_date(col("last_active_date"),"ddMMMyyyy")) \
             .withColumn( "active_order"
                         ,row_number().over(Window.partitionBy("ps_cci_member_id")
                                      .orderBy(col("active_last").desc()))) \
             .filter(col("active_order") == 1)  
print(demo.count()) 
print(demo.select("ps_cci_member_id").distinct().count())  

# COMMAND ----------

display(demo.groupBy("age_calc","sex").count())

# COMMAND ----------

bad_dupes=demo.select("ps_cci_member_id","sex","age") \
               .distinct() \
               .groupBy("ps_cci_member_id") \
               .count() \
               .filter(col("count")>1) \
               .select("ps_cci_member_id")
bad_dupes.count()    

# Write DataFrame to disk in Parquet format
bad_dupes.write.format("delta") \
         .mode("overwrite")  \
         .saveAsTable("MARKERS.drop_dopps")
print(bad_dupes.count())

# COMMAND ----------

demo_clean=demo.join( bad_dupes
                     ,"ps_cci_member_id"
                     ,"left_anti")
                         
print(demo_clean.select("ps_cci_member_id").distinct().count()) 
demo_clean.write \
          .format("delta") \
          .mode("overwrite") \
          .option("mergeSchema", "true") \
          .saveAsTable("demo_clean")

# COMMAND ----------

demo_marks=demo_clean.select( "ps_cci_member_id"
                             ,"marker") \
                         .distinct() \
                         .withColumn("value",lit(1))  
                         

# COMMAND ----------

display(demo_marks.groupBy("marker").count())

# COMMAND ----------

demo_marks.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("MARKERS.demographic")