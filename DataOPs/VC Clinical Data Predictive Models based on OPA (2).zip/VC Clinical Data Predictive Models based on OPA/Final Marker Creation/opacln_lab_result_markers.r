# Databricks notebook source
###############################################################################
# LAB RESULTS PROCESSING AND MARKER GENERATION PIPELINE
# Author: Sandeep Gaudana
# Description:
#   This script processes raw lab results, applies filtering rules,
#   generates markers based on predefined logic, and writes the results
#   to the Hive Metastore (markers schema).
###############################################################################

# ------------------------- LOAD REQUIRED LIBRARIES ---------------------------
library(data.table)   # Efficient data manipulation
library(arrow)        # For reading Parquet datasets
library(sparklyr)     # Spark integration for writing to Delta tables
library(dplyr)        # For Spark table operations

# ------------------------- STEP 0: LOAD ISSUE MEMBERS ------------------------
# Identify members with potential mapping issues (different members mapping to same ID)
root <- "/dbfs/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers/"
ds <- open_dataset(root, format = "parquet")  # Reads all Parquet files recursively
dt_member_w_issue <- as.data.table(sparklyr::collect(ds))

# ------------------------- STEP 0: LOAD RAW LAB RESULTS ----------------------
file_path <- "/dbfs/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/"
file_list <- list.files(path = file_path,
                        pattern = paste0("opa_clndcr_labresult_122924_", "[0-9]{0,9}", ".csv.gz"),
                        recursive = FALSE)

# Combine all parts into one data.table
combine_file <- list()
i <- 0
for (pt in file_list) {
  i <- i + 1
  file <- fread(cmd = paste0("gunzip -c ", file_path, pt),
                select = c("ps_cci_member_id","labres_groupid","labres_enc_id","labresult_date",
                           "loinc_n","name_m","units_cui_m","normalizedvalue","standardcode_cui",
                           "labresult_time","labres_emr_source"))
  combine_file[[i]] <- file
}
dt <- rbindlist(combine_file, use.names = TRUE, fill = TRUE)
print(paste0("Step 0: ", nrow(dt)))

# ------------------------- STEP 1: FILTER MEMBERS WITH ISSUES ----------------
dt <- dt[!ps_cci_member_id %in% dt_member_w_issue$ps_cci_member_id]
print(paste0("Step 1: ", nrow(dt)))

# ------------------------- STEP 2: REMOVE NULL VALUES ------------------------
dt <- dt[!is.na(loinc_n) & loinc_n != "" & !is.na(normalizedvalue)]
print(paste0("Step 2: ", nrow(dt)))

# ------------------------- STEP 3: REMOVE CLAIM LAB RESULTS ------------------
dt <- dt[labres_emr_source != "int_claim_labresult"]
print(paste0("Step 3: ", nrow(dt)))

# ------------------------- STEP 4: DATE FILTERING ----------------------------
# Keep only lab results within 183 days before 31-Dec-2023
dt[, labresult_date := as.Date(labresult_date, format = "%d%b%Y")]
cutoff_date <- as.Date("2023-12-31")
start_date <- cutoff_date - 183
dt <- dt[labresult_date >= start_date & labresult_date <= cutoff_date]
print(paste0("Step 4: ", nrow(dt)))

# ------------------------- STEP 5: HANDLE MULTIPLE RESULTS PER DAY ----------
dt[, labresult_time := as.POSIXct(labresult_time, format = "%H:%M:%S")]
setorder(dt, ps_cci_member_id, standardcode_cui, labresult_date, labresult_time)
dt <- dt[, .SD[.N], by = .(ps_cci_member_id, standardcode_cui, labresult_date)]
print(paste0("Step 5: ", nrow(dt)))

# ------------------------- STEP 6: LATEST RECORD PER MEMBER ------------------
dt <- dt[, .SD[.N], by = .(ps_cci_member_id, standardcode_cui)]
print(paste0("Step 6: ", nrow(dt)))

# ------------------------- SAVE FILTERED DATA --------------------------------
saveRDS(dt, file = "/dbfs/mnt/jvmlshare/jvmlshare/users/sgaudana/opa_lab_data.rds")

# Reload filtered data (to avoid rerunning steps)
# dt <- readRDS("/dbfs/mnt/jvmlshare/jvmlshare/users/sgaudana/opa_lab_data.rds")
# dt$ps_cci_member_id <- as.character(dt$ps_cci_member_id)

# ------------------------- MARKER GENERATION ---------------------------------
# Marker Group 1: Presence-based markers
cui_list <- c("CH000899","CH000898","CH000897","CH000947","CH001233",
              "CH001732","CH000895","CH001825","CH000646","CH000649")

marker_category1 <- unique(dt[, target_marker := fifelse(standardcode_cui %in% cui_list,
                                                         paste0("L_", standardcode_cui),
                                                         NA_character_)][!is.na(target_marker),
                                                                         .(ps_cci_member_id, target_marker)])
marker_category1[, target_value := 1L]

# Marker Group 2: Category-based markers
rules_other <- fread("/dbfs/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/map_lab_marker_other.csv", na.strings = c("", "NA"))
rules_other[, `:=`(min = as.numeric(min), max = as.numeric(max))]

DTM <- merge(dt, rules_other, by.x = "standardcode_cui", by.y = "cui", allow.cartesian = TRUE)
DTM[, in_range := !is.na(normalizedvalue) & (is.na(min) | normalizedvalue >= min) & (is.na(max) | normalizedvalue < max)]
DTM[in_range == TRUE, `:=`(target_marker = paste0("L_", standardcode_cui, "_", category), target_value = 1L)]
markers_long <- DTM[in_range == TRUE, .(ps_cci_member_id, target_marker, target_value)]

# Marker Group 3: Low/High threshold markers
rules <- fread("/dbfs/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/map_lab_marker.csv")
rules[, c("normal_lower","normal_upper") := lapply(.SD, as.numeric), .SDcols = c("normal_lower","normal_upper")]

make_markers <- function(dt_labs, rules) {
  L <- copy(dt_labs)
  if (!is.numeric(L$normalizedvalue)) suppressWarnings(L[, normalizedvalue := as.numeric(normalizedvalue)])
  R <- copy(rules); setnames(R, "cui", "standardcode_cui")
  L[R, c("normal_lower","normal_upper") := .(i.normal_lower, i.normal_upper), on = .(standardcode_cui)]
  L[, marker := fcase(!is.na(normal_lower) & normalizedvalue < normal_lower, "low",
                      !is.na(normal_upper) & normalizedvalue > normal_upper, "high",
                      default = NA_character_)]
  L[, target_marker := fifelse(!is.na(marker), sprintf("L_%s_%s", standardcode_cui, marker), NA_character_)]
  L[, target_value := fifelse(!is.na(marker), 1L, NA_integer_)]
  out_long <- L[!is.na(marker), .(ps_cci_member_id, target_marker, target_value)]
  out_long
}

out_markers <- make_markers(dt, rules)

# Combine all markers
marker <- rbind(marker_category1, markers_long, out_markers)

# Save marker output
saveRDS(marker, "/dbfs/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/lab_output/opa_lab_markers_final.rds")

# Reload marker data
# marker <- readRDS("/dbfs/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/lab_output/opa_lab_markers_final.rds")
# marker$ps_cci_member_id <- as.character(marker$ps_cci_member_id)

# ------------------------- WRITE TO HIVE METASTORE ---------------------------
sc <- spark_connect(method = "databricks")
marker_tbl <- copy_to(sc, marker, overwrite = TRUE)
spark_write_table(marker_tbl, name = "markers.lab_results", mode = "overwrite")

# COMMAND ----------

# rules_allowed <- c(rules$cui,unique(rules_other$cui),"CH000899","CH000898","CH000897","CH000947","CH001233","CH001732","CH000895","CH001825","CH000646","CH000649")
# dt <- dt[standardcode_cui %in% unique(rules_allowed)]
# saveRDS(dt,file=paste0("/dbfs/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/lab_output/opa_labresults_cleaned.rds"))


# COMMAND ----------

