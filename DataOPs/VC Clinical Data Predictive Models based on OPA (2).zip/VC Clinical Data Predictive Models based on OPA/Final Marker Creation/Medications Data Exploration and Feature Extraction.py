# Databricks notebook source
# MAGIC %md 
# MAGIC #### Processing Steps
# MAGIC ##### 1. Raw Data Loading
# MAGIC Load medication data and combine Patient Self-Reported domain data(rxr_raw) and Pharmacy Orders domain data (rxo_raw). 
# MAGIC
# MAGIC ##### 2. Data Source Filtering and Feature engineering
# MAGIC 1. Load medication data and filter for HOSP_IND = 0. (if we have administration data (rxa_raw))
# MAGIC 2. Filter by date to include only records from Jan 1 to Dec 31, 2023.
# MAGIC 3. Exclude PCC = 999 (which represents "Undefined NDC"). 
# MAGIC 4. Load IMAP_DCC.txt file to map DCC to PCC.
# MAGIC 5. Identify relevant PCCs for the pharmacological class using DCC.
# MAGIC 6. Check if at least one drug from the specified pharmacological class (via DCC → PCC mapping) was present in their medication records during the lookback period.
# MAGIC 7. Generate medication markers in the format MED_{PCC Code}.

# COMMAND ----------

from datetime import date
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, lit, concat, collect_set, broadcast, count
startDate = date(2023, 1, 1)
endDate = date(2023, 12, 31)

# COMMAND ----------

base_path = f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2"

# Load raw data
rxr_raw = spark.read.parquet(f"{base_path}/rxr_raw")
rxo_raw = spark.read.parquet(f"{base_path}/rxo_raw")
#rxa_raw = spark.read.parquet(f"{base_path}/rxa_raw")


# COMMAND ----------

# Combine Patient Self-Reported domain data(rxr_raw) and Pharmacy Orders domain data (rxo_raw)
med_data = rxr_raw.unionByName(rxo_raw, allowMissingColumns=True)
med_data.count()

# COMMAND ----------

# filtering for lookback period
# we can use 'medreported_date' if need to change
med_data=med_data\
    .withColumn("rxpatrpt_date", to_date(col("rxpatrpt_date"), "ddMMMyyyy"))
med_df = med_data.filter(
        col("rxpatrpt_date").between(startDate, endDate)
    )
med_df.count()         

# COMMAND ----------

# Load DCC to PCC mapping
imap_dcc = spark.read.option("delimiter", "|").csv(f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/IMAP_DCC.txt", header=True)
dcc_to_pcc = imap_dcc.select("DCC", "PCC").dropna().filter(col("PCC") != "999")
combine_df = med_df.join(broadcast(dcc_to_pcc), med_data.rxpat_dcc == dcc_to_pcc.DCC, how="inner")
combine_df.count()


# COMMAND ----------


from pyspark.sql.functions import count, col

combine_df = combine_df.groupBy(
    "ps_cci_member_id",
    "PCC").agg(count("*").alias("drug_count")).filter(col("drug_count") >= 1)
combine_df.count()


# COMMAND ----------

from pyspark.sql.functions import lit, concat

# Create medication marker column
marker_df = combine_df.withColumn(
    "Marker",
    concat(
        lit("MED_"),
        col("PCC").cast("string")
    )
)
marker_df=marker_df.select ("ps_cci_member_id", "Marker","drug_count")
display(marker_df)
marker_df.count()


# COMMAND ----------


marker_df.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("MARKERS.medication")
