# Databricks notebook source
# MAGIC %fs
# MAGIC ls dbfs:/mnt/jvmlstorage2fs/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/

# COMMAND ----------

# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

drop_dops=spark.read.parquet(f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/chimera")

# COMMAND ----------

enc_map = (spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv"))

idx_dx_23 = (
    spark.read.parquet(f"{base_path}/dx_23_raw/")
    .filter(~col("diag_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_dx_23", lit(1))
)
print("DX_23:")
print(idx_dx_23.count())

idx_dx_24 = (
    spark.read.parquet(f"{base_path}/dx_24_raw/")
    .filter(~col("diag_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_dx_24", lit(1))
)
print("DX_24:")
print(idx_dx_24.count())

idx_enc = (
    spark.read.parquet(f"{base_path}/enc_raw/")
    .filter(~col("enc_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .join(enc_map,col("hts_patient_type_cui")==col("CUI_CODE"),"left")
    .filter(~(col("Label").isNull()))
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_enc", lit(1))
)
print("Encounter:")
print(idx_enc.count())

idx_obs = (
    spark.read.parquet(f"{base_path}/obs_raw/")
    .filter(~col("obs_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_obs", lit(1))
)
print("OBS:")
print(idx_obs.count())

idx_px = (
    spark.read.parquet(f"{base_path}/px_raw/")
    .filter(~col("proc_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_px", lit(1))
)
print("PX:")
print(idx_px.count())

idx_rx0 = (
    spark.read.parquet(f"{base_path}/rxo_raw/")
    .filter(~col("rxord_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rx0", lit(1))
)
print("RX0:")
print(idx_rx0.count())

idx_rxa = (
    spark.read.parquet(f"{base_path}/rxa_raw/")
    .filter(~col("rxadm_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rxa", lit(1))
)
print("RXA:")
print(idx_rxa.count())

idx_rxr = (
    spark.read.parquet(f"{base_path}/rxr_raw/")
    .filter(~col("rxpat_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rxr", lit(1))
)
print("RXR:")
print(idx_rxr.count())

idx_lab = (
    spark.read.parquet(f"{base_path}/lab_raw/")
    .filter(~col("labres_emr_source").like("int_claim%"))
    .join( drop_dops
          ,"ps_cci_member_id"
          ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_lab", lit(1))
)
print("LAB:")
print(idx_lab.count())

# COMMAND ----------

from pyspark.sql import DataFrame
idxToJoin: list[DataFrame] = [idx_dx_24, idx_enc, idx_obs, idx_px, idx_rx0, idx_rxa, idx_rxr, idx_lab]

# COMMAND ----------

from functools import reduce

allPatKey = reduce(
    lambda accIdx, currentIdx: accIdx.join(
        currentIdx,
        on=["ps_cci_member_id"],
        how="fullouter"
    ),
    idxToJoin,
    idx_dx_23
).withColumn(
        "idx_dx",
        when((col("idx_dx_24") == 1) | (col("idx_dx_23") == 1), 1).otherwise(0)
).withColumn( "idx_rx",
        when((col("idx_rx0") == 1) | (col("idx_rxr") == 1) | (col("idx_rxa") == 1), 1).otherwise(0)     
)

# COMMAND ----------

display(
    allPatKey.select( col("ps_cci_member_id").alias("Patient") 
                 ,col("idx_enc").alias("Encounter") 
                 ,col("idx_obs").alias("Observation") 
                 ,col("idx_px").alias("Procedure") 
                 ,col("idx_lab").alias("Lab Results") 
                 ,col("idx_dx").alias("Diagnosis") 
                 ,col("idx_rx").alias("Medications") )
    )

# COMMAND ----------

allPatKey.groupBy("ps_cci_member_id").count().filter(col("count") > 1).show()

# COMMAND ----------

allPatKey.count()

# COMMAND ----------

# DBTITLE 1,Domain Population Overlap
capture_counts=allPatKey.agg(
        sum("idx_dx").alias("idx_dx"),
        sum("idx_enc").alias("idx_enc"),
        sum("idx_obs").alias("idx_obs"),
        sum("idx_px").alias("idx_px"),
        sum("idx_rx").alias("idx_rx"),
        sum("idx_lab").alias("idx_lab"))  \
        .withColumn("piv_point",lit("piv")) \
      .unpivot( ids=["piv_point"]
               ,values=["idx_dx","idx_enc","idx_obs","idx_px","idx_rx","idx_lab"]
               ,variableColumnName="key",valueColumnName="value") \
      .withColumn("Found",col("value")/allPatKey.count()
     ).withColumn("Not Found",lit(1)-col("Found")
     ).withColumn("patients",col("value")
     ).withColumn("missing",lit(allPatKey.count())-col("value"))

display(capture_counts)   

# COMMAND ----------

# MAGIC %md
# MAGIC **Chi Squared Testing for Independence**
# MAGIC
# MAGIC Test the independence between the number of patients found and missing for each data source, in order to determine if missingness is systematic or random.
# MAGIC
# MAGIC **Inputs**:
# MAGIC
# MAGIC capture_counts: Spark DataFrame with columns:
# MAGIC Patients: Number of patients found for each source (should be integer or float).
# MAGIC Missing: Number of patients missing for each source (should be integer or float).
# MAGIC
# MAGIC **Outputs:**
# MAGIC
# MAGIC Chi-squared statistic and p-value.
# MAGIC Interpretation guidance:
# MAGIC A significant p-value indicates systematic missingness.
# MAGIC A non-significant p-value suggests data is missing at random.
# MAGIC
# MAGIC Assumptions:
# MAGIC
# MAGIC The capture_counts DataFrame has no nulls in the Patients and Missing columns.
# MAGIC The data is aggregated such that each row represents a data source.
# MAGIC Limitations:
# MAGIC
# MAGIC Only tests independence between two columns (Patients and Missing).
# MAGIC Assumes the data is suitable for a Chi-squared test (counts, not continuous values).Cell Name: Chi Squared Testing for Independence
# MAGIC

# COMMAND ----------

# DBTITLE 1,Chi Squared Testing for Independence
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import ChiSquareTest

assembler = VectorAssembler(
    inputCols=["Patients"],  # Features
    outputCol="features"
)

df_vec = assembler.transform(capture_counts.select("Patients", "Missing"))

chi_sq_result = ChiSquareTest.test(
    df_vec,
    featuresCol="features",
    labelCol="Missing"
)

result = chi_sq_result.collect()[0]

print(f"Chi-square Statistic: {result['statistics'][0]}")
print(f"P-value: {result['pValues'][0]}")

# A significant p-value indicates that the sources are missing patients systematically.
# A non-significant p-value suggests data is missing randomly

# COMMAND ----------

# DBTITLE 1,Correlation
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation
import pandas as pd

pat_vec=VectorAssembler( inputCols=["idx_dx",
                                    "idx_enc",
                                    "idx_obs",
                                    "idx_px",
                                    "idx_rx",
                                    "idx_lab"]
                         ,outputCol="features")

pat_link_vec=pat_vec.transform(allPatKey.na.fill(0))

# Compute the correlation matrix
correlation_matrix = Correlation.corr(pat_link_vec, "features", method="pearson").head()[0]

# Display the correlation matrix
# Convert to a Pandas DataFrame for better readability
matrix_array = correlation_matrix.toArray()
correlation_df = pd.DataFrame( matrix_array
                              ,columns=["idx_dx",
                                    "idx_enc",
                                    "idx_obs",
                                    "idx_px",
                                    "idx_rx",
                                    "idx_lab"]
                              ,index=["idx_dx",
                                    "idx_enc",
                                    "idx_obs",
                                    "idx_px",
                                    "idx_rx",
                                    "idx_lab"])

# Display the correlation matrix
print(correlation_df)