# Databricks notebook source
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt
import seaborn as sns

# COMMAND ----------

recap = spark.table("cap_recap")
xdf = recap.toPandas()
relevant_cols = [
    'count', 'idx_dx','idx_enc','idx_obs','idx_px','idx_rx','idx_lab','hi_int_dx','hi_int_enc','hi_int_obs','hi_int_px','hi_int_rx','hi_int_lab','all'
]
df_clean = xdf[
    relevant_cols
].replace([np.inf, -np.inf], np.nan).dropna()

# COMMAND ----------

xdf.columns

# COMMAND ----------

display(xdf)

# COMMAND ----------

base='count ~ idx_dx+idx_enc+idx_obs+idx_px+idx_rx+idx_lab'
base_all='count ~ idx_dx+idx_enc+idx_obs+idx_px+idx_rx+idx_lab+all'
base_intsen='count ~ idx_dx+idx_enc+idx_obs+idx_px+idx_rx+idx_lab+hi_int_dx+hi_int_enc+hi_int_obs+hi_int_px+hi_int_rx+hi_int_lab'
base_intsen_all='count ~ idx_dx+idx_enc+idx_obs+idx_px+idx_rx+idx_lab+hi_int_dx+hi_int_enc+hi_int_obs+hi_int_px+hi_int_rx+hi_int_lab+all'
base_intsen_intx='count ~ idx_dx+idx_enc+idx_obs+idx_px+idx_rx+idx_lab+hi_int_dx+hi_int_enc+hi_int_obs+hi_int_px+hi_int_rx+hi_int_lab+idx_dx*hi_int_dx+idx_px*hi_int_px+idx_rx*hi_int_rx+idx_enc*hi_int_enc+idx_obs*hi_int_obs+idx_lab*hi_int_lab'


# COMMAND ----------


# Fit Poisson regression
model = smf.glm( formula=base
                ,data=df_clean
                ,family=sm.families.NegativeBinomial(link=sm.families.links.log())).fit(method="lbfgs")
print(model.summary())

# 3. Predictions
df_clean['fitted'] = model.fittedvalues
df_clean['pearson_resid'] = model.resid_pearson

# 4. Residual vs Fitted plot
plt.figure(figsize=(8,6))
sns.scatterplot(x='fitted', y='pearson_resid', data=df_clean)
plt.axhline(0, color='red', linestyle='--')
plt.title('Pearson Residual vs Fitted Values')
plt.xlabel('Fitted Values')
plt.ylabel('Pearson Residuals')
plt.show()

# 5. Interpretation
print("Exponentiated coefficients (Rate Ratios):")
print(np.exp(model.params))

# COMMAND ----------

display(df_clean)