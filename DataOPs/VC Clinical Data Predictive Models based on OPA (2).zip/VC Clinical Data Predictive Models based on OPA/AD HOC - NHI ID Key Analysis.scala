// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

// DBTITLE 1,Read Data
val raw_demo=spark.read
                 .option( "header"
                         ,"true")
                 .option( "inferSchema"
                         ,"true")
                 .csv(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/opa_cln_patient_rollup_122914_*.csv.gz")
                 .withColumn("dob",to_date($"pat_dob","ddMMMyyyy"))
                 .withColumn("dod",to_date($"pat_date_of_death","ddMMMyyyy"))
                 .withColumn("active_last",to_date($"last_active_date","ddMMMyyyy"))

// COMMAND ----------

// DBTITLE 1,Prep
val interval=5
val demo=raw_demo.filter(($"dod">=endDate||$"dod".isNull) && !($"dob".isNull))
                 .filter($"pat_gender_cui_m".isin("CH000033","CH000034"))
                 .withColumn("sex",when($"pat_gender_cui_m"==="CH000033","F").otherwise("M"))
                 .withColumn( "age"
                             ,floor(months_between(lit(startDate),to_date($"dob","yyyyMMdd"))/12))
                 .withColumn("range",$"age"-($"age"%interval))
                 .withColumn("marker",concat(lit("D_"),$"sex",$"range",lit("_"),$"range"+interval))         
                 .filter($"age">=0 && $"age"<=102) 
                 .filter($"active_last">=startDate)  
println(demo.count()) 
println(demo.select("ps_cci_member_id").distinct().count())  

// COMMAND ----------

// DBTITLE 1,Identify badly aggregated IDs
val bad_dupes=demo.select("ps_cci_member_id","sex","age")
                  .distinct()
                  .groupBy("ps_cci_member_id")
                  .count()
                  .filter($"count">1)
                  .select("ps_cci_member_id")
bad_dupes.count()       
// Need this list as reusable object           

// COMMAND ----------

// DBTITLE 1,Clean bad IDS
val demo_clean=demo.join(bad_dupes,"ps_cci_member_id","left_anti")
println(demo_clean.select("ps_cci_member_id").distinct().count()) 

// COMMAND ----------

11441245-11418299

// COMMAND ----------

///////

// COMMAND ----------

val dup_details=demo.join(bad_dupes,Seq("ps_cci_member_id"),"right")
      .select( "ps_cci_member_id"
              ,"pat_groupid"
              ,"pat_match_lvl_flg_desc"
              ,"update_date"
              ,"state"
              ,"sex"
              ,"age")
      .distinct()

// COMMAND ----------

// DBTITLE 1,Groupid by Bad Duplicates
val row_count_demo=demo.count().toDouble
val dem_grp=demo.groupBy("pat_groupid")
                .agg(count("*").as("freq"))
                .withColumn("prop_demo",col("freq")/lit(row_count_demo))

val row_count_dupe=dup_details.count().toDouble
val dup_grp=dup_details.groupBy("pat_groupid")
      .agg(count("*").as("freq"))
      .withColumn("prop_dupe",col("freq")/lit(row_count_dupe))  

display(dem_grp.join(dup_grp,Seq("pat_groupid"),"left"))   

// COMMAND ----------

//Just punt the problematic people small population?

// COMMAND ----------

// DBTITLE 1,HGroup by Zip/State
raw_demo.columns