// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

  def convertCsvToParquet( csvInputPath: String
                          ,parquetOutputPath: String): Unit = {

    // Incoming CSV
    val incoming=spark.read.format("csv").option("header","true").option("inferschema","true").load(csvInputPath)
    // Out to parquet
    val prq_out=incoming.write.format("parquet").mode(SaveMode.Overwrite).save(parquetOutputPath)

    println(s"Successfully converted CSV from '$csvInputPath' to Parquet at '$parquetOutputPath'")
  }

def patIDX( parq_file: String
           ,idx: String ):Unit={
    val pat_idx=spark.read.parquet(parq_file).select("ps_cci_member_id").distinct()  
    pat_idx.write.format("parquet").mode(SaveMode.Overwrite).save(idx)
}

// COMMAND ----------

val base_path=f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2"

// COMMAND ----------

// MAGIC %md
// MAGIC •	opa_cln_lds_encounterreas_123068 
// MAGIC
// MAGIC •	opa_cln_zh_provider_122940  

// COMMAND ----------

// DBTITLE 1,opa_cln_zh_provider_122940
convertCsvToParquet(f"$base_path/opa_cln_zh_provider_122940_*.csv.gz",f"$base_path/spec_raw")
//patIDX(f"$base_path/spec_raw",f"$base_path/idx_spec")

// COMMAND ----------

val spec=spark.read.parquet(f"$base_path/spec_raw")
val px=spark.read.parquet(f"$base_path/px_raw")
val enc=spark.read.parquet(f"$base_path/enc_raw")


// COMMAND ----------

// DBTITLE 1,opa_cln_lds_encountercare_123069
convertCsvToParquet(f"$base_path/opa_cln_lds_encountercare_123069_*.csv.gz",f"$base_path/enc_area_raw")
patIDX(f"$base_path/enc_area_raw",f"$base_path/idx_enc_area")

// COMMAND ----------

// DBTITLE 1,opa_cln_patient_rollup_123307
convertCsvToParquet(f"$base_path/opa_cln_patient_rollup_123307_*.csv.gz",f"$base_path/demo_raw")
patIDX(f"$base_path/demo_raw",f"$base_path/idx_demo")

// COMMAND ----------

// DBTITLE 1,opa_cln_lds_procedure_123063
//Original Source opa_cln_lds_procedure_123063
convertCsvToParquet(f"$base_path/opa_cln_lds_procedure_123362_*.csv.gz",f"$base_path/px_raw")
patIDX(f"$base_path/px_raw",f"$base_path/idx_px")

// COMMAND ----------

// DBTITLE 1,opa_cln_lds_diagnosis_y24_123226
convertCsvToParquet(f"$base_path/opa_cln_lds_diagnosis_y24_123226_*.csv.gz",f"$base_path/dx_24_raw")
patIDX(f"$base_path/dx_24_raw",f"$base_path/idx_dx_24")

// COMMAND ----------

// DBTITLE 1,opa_cln_lds_diagnosis_y23_123226
convertCsvToParquet(f"$base_path/opa_cln_lds_diagnosis_y23_123185_*.csv.gz",f"$base_path/dx_23_raw")
patIDX(f"$base_path/dx_23_raw",f"$base_path/idx_dx_23")

// COMMAND ----------

// DBTITLE 1,opa_clndcr_encounter_123067
convertCsvToParquet(f"$base_path/opa_clndcr_encounter_123067_*.csv.gz",f"$base_path/enc_raw")
patIDX(f"$base_path/enc_raw",f"$base_path/idx_enc")

// COMMAND ----------

// DBTITLE 1,opa_cln_lds_observation_123153
convertCsvToParquet(f"$base_path/opa_cln_lds_observation_123153_*.csv.gz",f"$base_path/obs_raw")
patIDX(f"$base_path/obs_raw",f"$base_path/idx_obs")

// COMMAND ----------

// DBTITLE 1,opa_cln_lds_elig_insuranc_123061
convertCsvToParquet(f"$base_path/opa_cln_lds_elig_insuranc_123061_*.csv.gz",f"$base_path/ins_raw")
patIDX(f"$base_path/ins_raw",f"$base_path/idx_ins")

// COMMAND ----------

// DBTITLE 1,opa_cln_lds_rx_patient_re_123070
convertCsvToParquet(f"$base_path/opa_cln_lds_rx_patient_re_123070_*.csv.gz",f"$base_path/rxr_raw")
patIDX(f"$base_path/rxr_raw",f"$base_path/idx_rxr")

// COMMAND ----------

// DBTITLE 1,opa_cln_lds_rxadmin_123064
convertCsvToParquet(f"$base_path/opa_cln_lds_rxadmin_123064_*.csv.gz",f"$base_path/rxa_raw")
patIDX(f"$base_path/rxa_raw",f"$base_path/idx_rxa")

// COMMAND ----------

// DBTITLE 1,opl_cln_lds_rxorder_123066
convertCsvToParquet(f"$base_path/opl_cln_lds_rxorder_123066_*.csv.gz",f"$base_path/rxo_raw")
patIDX(f"$base_path/rxo_raw",f"$base_path/idx_rx0")

// COMMAND ----------

// DBTITLE 1,opa_clndcr_labresult_123247
convertCsvToParquet(f"$base_path/opa_clndcr_labresult_123247_*.csv.gz",f"$base_path/lab_raw")
patIDX(f"$base_path/lab_raw",f"$base_path/idx_lab")

// COMMAND ----------

// DBTITLE 1,AD_Hoc_QA
spark.read.parquet(f"$base_path/idx_lab").count()

// COMMAND ----------

display(
  spark.read.parquet(f"$base_path/lab_raw")
       .filter(col("standardcode_cui")===lit("CH002121"))
       .filter(col("units_cui_m")===lit("CH000197"))
       .groupBy(col("normalizedvalue"),col("labres_groupid")).count()
)

// COMMAND ----------

display(spark.read.parquet(f"$base_path/lab_raw")
             .filter(col("standardcode_cui")===lit("CH002121"))
             .groupBy("normalrange").count())

// COMMAND ----------

