// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

// DBTITLE 1,Duplicates
val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")

// COMMAND ----------

// DBTITLE 1,Retro Period Eligibility IDX load
val retro_pats_idx=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/retro_pats_idx")

// COMMAND ----------

// DBTITLE 1,Encounter MAPS
val enc_map = spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv")

val disp_cat_map=spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_disp_cat.csv")

val enc_raw=spark.read.parquet(f"$base_path/enc_raw")
                 .withColumn("arrive_date",to_date($"enc_arrivaldate","ddMMMyyyy"))
                 .withColumn("admit_date",to_date($"enc_admitdate","ddMMMyyyy"))
                 .withColumn( "disch_date"
                              ,when(col( "discharge_date").isNull
                                        ,col("arrive_date"))
                              .otherwise(to_date($"discharge_date","ddMMMyyyy")))
                 .join( drop_dops
                       ,"ps_cci_member_id"
                       ,"left_anti")

val enc_prep=enc_raw.filter($"arrive_date".between(startDate,endDate))
                    .join(enc_map,enc_raw("hts_patient_type_cui")===enc_map("CUI_CODE"),"left")
                    .join(disp_cat_map,enc_raw("discharge_disp_m")===disp_cat_map("Concept_CUI"),"left")

// COMMAND ----------



// COMMAND ----------

display(enc_map)

// COMMAND ----------

enc_prep.columns

// COMMAND ----------

 val hgrp_freq=enc_prep.select( "ps_cci_member_id"
                               ,"enc_groupid")
                              //,"arrive_date")
                      .distinct()
                      .groupBy("enc_groupid")
                      .agg(count("*").as("hgrp_fq")) 
display(hgrp_freq)

// COMMAND ----------

val enc_hgrp=enc_prep.select( "ps_cci_member_id"
                             ,"enc_groupid" //,"arrive_date"
                             ,"Label" //"hts_patient_type_cui"
                             )
                     .distinct()
                     .groupBy("enc_groupid","Label")//"hts_patient_type_cui")
                     .agg(count("*").as("enc_fq")) 
display(enc_hgrp)

// COMMAND ----------

// DBTITLE 1,Encounter Type Patient Type Profile
//H053731, H984216, H770958
val q= hgrp_freq.join(enc_hgrp,Seq("enc_groupid"),"left")
                  .filter($"hgrp_fq">lit(1000))
                  .withColumn("prop",$"enc_fq"/$"hgrp_fq")
display(q)                  

// COMMAND ----------

display(
  enc_prep.select( "ps_cci_member_id"
                ,"enc_groupid")
              //,"arrive_date")
         .distinct()
         .groupBy("ps_cci_member_id")
         .count().groupBy("count").count())  

// COMMAND ----------

// 7.5% Matched Patient ids show up in different H-Groups

// COMMAND ----------

val multi_members=enc_prep.select( "ps_cci_member_id"
                                  ,"enc_groupid")
                                  //,"arrive_date")
                          .distinct()
                          .groupBy("ps_cci_member_id")
                          .count().filter($"count">1)

// COMMAND ----------

val mm_hgrp=multi_members.select("ps_cci_member_id").join(enc_prep.select( "ps_cci_member_id","enc_groupid").distinct(),Seq("ps_cci_member_id"),"left")

// COMMAND ----------

display(
  mm_hgrp.select($"ps_cci_member_id",$"enc_groupid".as("a_id"))
         .join( mm_hgrp.select($"ps_cci_member_id",$"enc_groupid".as("b_id"))
               ,Seq("ps_cci_member_id")
               ,"inner")
         .filter($"a_id"=!=$"b_id").groupBy($"a_id",$"b_id").agg(count("*").as("value"))
  )

// COMMAND ----------

// DBTITLE 1,Does Payer Elig help?
val payer_enc= retro_pats_idx.join(enc_prep,Seq("ps_cci_member_id"),"left")
println(payer_enc.count())

// COMMAND ----------

display(
payer_enc.select( "ps_cci_member_id"
                               ,"enc_groupid")
                              //,"arrive_date")
                      .distinct()
                      .groupBy("enc_groupid")
                      .agg(count("*").as("hgrp_fq")) 
)

// COMMAND ----------

display(
  payer_enc.select( "ps_cci_member_id"
                ,"enc_groupid")
              //,"arrive_date")
         .distinct()
         .groupBy("ps_cci_member_id")
         .count().groupBy("count").count()) 

// COMMAND ----------

display(payer_enc.select( "ps_cci_member_id"
                                  ,"enc_groupid")
                                  //,"arrive_date")
                          .distinct()
                          .groupBy("ps_cci_member_id")
                          .count().filter($"count">1))

// COMMAND ----------

val multi_pays=payer_enc.select( "ps_cci_member_id"
                                  ,"enc_groupid")
                                  //,"arrive_date")
                          .distinct()
                          .groupBy("ps_cci_member_id")
                          .count().filter($"count">1)

// COMMAND ----------

val mm_pay_hgrp=multi_pays.select("ps_cci_member_id").join(enc_prep.select( "ps_cci_member_id","enc_groupid").distinct(),Seq("ps_cci_member_id"),"left")

// COMMAND ----------

display(
  mm_pay_hgrp.select($"ps_cci_member_id",$"enc_groupid".as("a_id"))
         .join( mm_hgrp.select($"ps_cci_member_id",$"enc_groupid".as("b_id"))
               ,Seq("ps_cci_member_id")
               ,"inner")
         .filter($"a_id"=!=$"b_id").groupBy($"a_id",$"b_id").agg(count("*").as("value"))
  )