// Databricks notebook source
// MAGIC %python
// MAGIC # Replace these with your actual values
// MAGIC storage_account_name = "ovemldev"
// MAGIC container_name = "nonuc"
// MAGIC access_key = "1KGe1jTkEqTACFbbz2ghv1PMpJExBtBfow2o7zgNJa06yvGJokXJAJXHASAb+rWO/MbyQWdf2XiS+AStIPHPCA=="
// MAGIC
// MAGIC # Set Spark configuration to use the access key
// MAGIC spark.conf.set(f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net", access_key)

// COMMAND ----------

val storage_account_name = "ovemldev"
val container_name = "nonuc"
//Define the path to the container
var adls_path = f"abfss://$container_name@$storage_account_name.dfs.core.windows.net/"

// COMMAND ----------

import java.sql.Date
import org.apache.spark.sql.types
import org.apache.spark.sql.functions._

// COMMAND ----------

val root_src="dbfs:/mnt/jvmlshare"
val base_path=f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2"

val startDate=Date.valueOf("2023-01-01")
val endDate=Date.valueOf("2023-12-31")

val proStartDate=Date.valueOf("2024-01-01")
val proEndDate=Date.valueOf("2024-12-31")

// COMMAND ----------

// MAGIC %fs
// MAGIC ls 

// COMMAND ----------

// MAGIC %fs
// MAGIC ls dbfs:/mnt/jvmlshare