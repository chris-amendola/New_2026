# Databricks notebook source
from pyspark.sql.functions import to_date, col

# COMMAND ----------

# MAGIC %md
# MAGIC Reading enc_raw
# MAGIC

# COMMAND ----------

path = f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/enc_raw"

# COMMAND ----------

df = spark.read.parquet(path)

# COMMAND ----------

display(df)
df.count()

# COMMAND ----------

enc_df = df.withColumn(
    "enc_date",
    to_date(col("enc_arrivaldate"), "ddMMMyyyy")
).filter(
    col("enc_date").between("2023-01-01", "2023-12-31")
)
display(enc_df)

# COMMAND ----------

display(enc_df.count())

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/px_raw

# COMMAND ----------

path2 = f"dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/px_raw"

# COMMAND ----------

px_raw =  spark.read.parquet(path2)
display(px_raw)
px_raw.count()

# COMMAND ----------

from pyspark.sql.functions import to_date, col

px_raw = px_raw.withColumn(
    "px_date",
    to_date(col("proc_date"), "ddMMMyyyy")
)
display(px_raw)

# COMMAND ----------

from pyspark.sql.functions import col, to_date

# Parse date columns to DateType
px_raw_fixed = px_raw.withColumn(
    "px_date", to_date(col("px_date"), "ddMMMyyyy")
)
enc_df_fixed = enc_df.withColumn(
    "enc_date", to_date(col("enc_date"), "ddMMMyyyy")
).withColumn(
    "discharge_date", to_date(col("discharge_date"), "ddMMMyyyy")
)

# Join on member id and date range
joined_df = px_raw_fixed.join(
    enc_df_fixed,
    (px_raw_fixed.ps_cci_member_id == enc_df_fixed.ps_cci_member_id) &
    (col("px_date") >= col("enc_date")) &
    (col("px_date") <= col("discharge_date")),
    "inner"
).drop(enc_df_fixed.ps_cci_member_id)

display(joined_df)

# COMMAND ----------

dopps = "dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/doppleganger"

# COMMAND ----------


drop_dops = spark.read.parquet(dopps)

# COMMAND ----------

display(drop_dops)

# COMMAND ----------

drop_dops.count()

# COMMAND ----------

merged_dx = (
    joined_df.filter(col("proc_codetype") == "ICD10")
    .join(drop_dops, on="ps_cci_member_id", how="left_anti")
)

# COMMAND ----------

display(merged_dx)

# COMMAND ----------

merged_dxc =  merged_dx.select("ps_cci_member_id","enc_groupid")

# COMMAND ----------

display(merged_dxc.count())

# COMMAND ----------

merged_dxc = merged_dxc.dropDuplicates()

# COMMAND ----------

display(merged_dxc.count())

# COMMAND ----------

display(merged_dxc)

# COMMAND ----------

path3 = "dbfs:/mnt/jvmlshare/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/spec_raw/"

# COMMAND ----------

specialty_specs = spark.read.parquet(path3)

# COMMAND ----------

display(specialty_specs)

# COMMAND ----------

# Join merged_dx with specialty_specs on enc_groupid and prvspc_groupid columns
final_table = (
    merged_dxc.join(
        specialty_specs,
        merged_dxc.enc_groupid == specialty_specs.prvspc_groupid,
        "left"
    )
    .select(merged_dxc["*"], specialty_specs["prvspc_cui"])
)
display(final_table)

# COMMAND ----------

import pandas as pd

# Define the data
data = [
    {"CUI_SPEC": "CH000981", "SPEC_DESC": "Primary Care", "SPEC_MARKER_NAME": "SPEC_PRIMARY_CARE"},
    {"CUI_SPEC": "CH000796", "SPEC_DESC": "Allergy and Immunology", "SPEC_MARKER_NAME": "SPEC_ALLERGY_IMMUNOLOGY"},
    {"CUI_SPEC": "CH000854", "SPEC_DESC": "Cardiology", "SPEC_MARKER_NAME": "SPEC_CARDIOLOGY"},
    {"CUI_SPEC": "CH000809", "SPEC_DESC": "Dermatology", "SPEC_MARKER_NAME": "SPEC_DERMATOLOGY"},
    {"CUI_SPEC": "CH000859", "SPEC_DESC": "Endocrinology", "SPEC_MARKER_NAME": "SPEC_ENDOCRINOLOGY"},
    {"CUI_SPEC": "CH000860", "SPEC_DESC": "Gastroenterology/Hepatology", "SPEC_MARKER_NAME": "SPEC_GASTRO_HEPATOLOGY"},
    {"CUI_SPEC": "CH000863", "SPEC_DESC": "Gastroenterology/Hepatology", "SPEC_MARKER_NAME": "SPEC_GASTRO_HEPATOLOGY"},
    {"CUI_SPEC": "CH000862", "SPEC_DESC": "Hematology/Oncology", "SPEC_MARKER_NAME": "SPEC_HEMATOLOGY_ONCOLOGY"},
    {"CUI_SPEC": "CH000866", "SPEC_DESC": "Hematology/Oncology", "SPEC_MARKER_NAME": "SPEC_HEMATOLOGY_ONCOLOGY"},
    {"CUI_SPEC": "CH000867", "SPEC_DESC": "Nephrology", "SPEC_MARKER_NAME": "SPEC_NEPHROLOGY"},
    {"CUI_SPEC": "CH000868", "SPEC_DESC": "Neurology", "SPEC_MARKER_NAME": "SPEC_NEUROLOGY"},
    {"CUI_SPEC": "CH000872", "SPEC_DESC": "Psychiatry", "SPEC_MARKER_NAME": "SPEC_PSYCHIATRY"},
    {"CUI_SPEC": "CH000874", "SPEC_DESC": "Pulmonary Medicine", "SPEC_MARKER_NAME": "SPEC_PULMONARY MEDICINE"},
    {"CUI_SPEC": "CH000875", "SPEC_DESC": "Rheumatology", "SPEC_MARKER_NAME": "SPEC_RHEUMATOLOGY"},
    {"CUI_SPEC": "CH000851", "SPEC_DESC": "Thoracic & Cardiovascular Surgery", "SPEC_MARKER_NAME": "SPEC_THORACIC_CARDIO_SURG"},
    {"CUI_SPEC": "CH001539", "SPEC_DESC": "General  Surgery", "SPEC_MARKER_NAME": "SPEC_GENERAL_SURG"},
    {"CUI_SPEC": "CH000849", "SPEC_DESC": "General  Surgery", "SPEC_MARKER_NAME": "SPEC_GENERAL_SURG"},
    {"CUI_SPEC": "CH000820", "SPEC_DESC": "Neurosurgery", "SPEC_MARKER_NAME": "SPEC_NEUROSURGERY"},
    {"CUI_SPEC": "CH000825", "SPEC_DESC": "Obstetrics and Gynecology", "SPEC_MARKER_NAME": "SPEC_OBGYN"},
    {"CUI_SPEC": "CH000827", "SPEC_DESC": "Ophthalmology", "SPEC_MARKER_NAME": "SPEC_OPHTHALMOLOGY"},
    {"CUI_SPEC": "CH000830", "SPEC_DESC": "Orthopedic Surgery", "SPEC_MARKER_NAME": "SPEC_ORTHOPEDIC_SURG"},
    {"CUI_SPEC": "CH000832", "SPEC_DESC": "Otolaryngology", "SPEC_MARKER_NAME": "SPEC_OTOLARYNGOLOGY"},
    {"CUI_SPEC": "CH000839", "SPEC_DESC": "Plastic Surgery", "SPEC_MARKER_NAME": "SPEC_PLASTIC_SURG"},
    {"CUI_SPEC": "CH000853", "SPEC_DESC": "Urology", "SPEC_MARKER_NAME": "SPEC_UROLOGY"},
    {"CUI_SPEC": "CH000865", "SPEC_DESC": "Infectious Disease", "SPEC_MARKER_NAME": "SPEC_INFECTIOUS_DISEASE"},
    {"CUI_SPEC": "CH000798", "SPEC_DESC": "Anesthesiology", "SPEC_MARKER_NAME": "SPEC_ANESTHESIOLOGY"},
    {"CUI_SPEC": "CH000834", "SPEC_DESC": "Pathology", "SPEC_MARKER_NAME": "SPEC_PATHOLOGY"},
    {"CUI_SPEC": "CH000845", "SPEC_DESC": "Radiology", "SPEC_MARKER_NAME": "SPEC_RADIOLOGY"},
    {"CUI_SPEC": "CH000824", "SPEC_DESC": "Dietician/Nutrition", "SPEC_MARKER_NAME": "SPEC_DIETICIAN_NUTRITION"},
    {"CUI_SPEC": "CH000843", "SPEC_DESC": "Behavioral Health", "SPEC_MARKER_NAME": "SPEC_BEHAVIORAL_HEALTH"},
    {"CUI_SPEC": "CH000844", "SPEC_DESC": "Behavioral Health", "SPEC_MARKER_NAME": "SPEC_BEHAVIORAL_HEALTH"},
    {"CUI_SPEC": "CH000806", "SPEC_DESC": "Behavioral Health", "SPEC_MARKER_NAME": "SPEC_BEHAVIORAL_HEALTH"},
    {"CUI_SPEC": "CH000848", "SPEC_DESC": "Social Work", "SPEC_MARKER_NAME": "SPEC_SOCIAL_WORK"},
    {"CUI_SPEC": "CH000855", "SPEC_DESC": "Social Work", "SPEC_MARKER_NAME": "SPEC_SOCIAL_WORK"}
]

# Create pandas DataFrame
df = pd.DataFrame(data)


# COMMAND ----------

# Convert pandas DataFrame to Spark DataFrame
spark_df = spark.createDataFrame(df)

# Save as a table in Databricks
spark_df.write.mode("overwrite").saveAsTable("specialties_table")

# COMMAND ----------

# Run this in a notebook cell
display(spark.sql("SELECT * FROM specialties_table"))

# COMMAND ----------

specialties_table = spark.table("specialties_table")

final_joined = final_table.join(
    specialties_table,
    final_table.prvspc_cui == specialties_table.CUI_SPEC,
    "left"
)

display(final_joined)

# COMMAND ----------

final_joined_nonull = final_joined.filter(final_joined.CUI_SPEC.isNotNull())
display(final_joined_nonull)

# COMMAND ----------

final_selected = final_joined_nonull.select("ps_cci_member_id", "SPEC_MARKER_NAME")
display(final_selected)

# COMMAND ----------

from pyspark.sql.functions import lit, col

clin_condtion_marks = final_selected.select(
    col("ps_cci_member_id"),
    col("SPEC_MARKER_NAME").alias("marker")
).withColumn("value", lit(1))

# COMMAND ----------

display(clin_condtion_marks)

# COMMAND ----------

clin_condtion_marks.dropDuplicates()

# COMMAND ----------

display(clin_condtion_marks.count())

# COMMAND ----------

# Now write your DataFrame as a new table
clin_condtion_marks.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("MARKERS.spacialty")