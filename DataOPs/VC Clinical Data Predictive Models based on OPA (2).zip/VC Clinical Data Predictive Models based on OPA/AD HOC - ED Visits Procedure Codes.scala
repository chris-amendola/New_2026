// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")

// COMMAND ----------

// DBTITLE 1,Procedure Data Load
val procedure_raw=spark.read.parquet(f"$base_path/px_raw")

val px=procedure_raw.withColumn("px_date",to_date($"proc_date","ddMMMyyyy"))
                    .filter($"px_date".between(startDate,endDate))
                    .join( drop_dops
                          ,"ps_cci_member_id"
                          ,"left_anti")

// COMMAND ----------

// DBTITLE 1,Encounter Data Load
val enc_map = spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv")

val disp_cat_map=spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_disp_cat.csv")

val enc_raw=spark.read.parquet(f"$base_path/enc_raw")
                 .withColumn("arrive_date",to_date($"enc_arrivaldate","ddMMMyyyy"))
                 .withColumn("admit_date",to_date($"enc_admitdate","ddMMMyyyy"))
                 .withColumn( "disch_date"
                              ,when(col( "discharge_date").isNull
                                        ,col("arrive_date"))
                              .otherwise(to_date($"discharge_date","ddMMMyyyy")))
                 .join( drop_dops
                       ,"ps_cci_member_id"
                       ,"left_anti")

val enc_prep=enc_raw.filter($"arrive_date".between(startDate,endDate))
                    .join(enc_map,enc_raw("hts_patient_type_cui")===enc_map("CUI_CODE"),"left")
                    .join(disp_cat_map,enc_raw("discharge_disp_m")===disp_cat_map("Concept_CUI"),"left")

// COMMAND ----------

display(enc_map)

// COMMAND ----------

// DBTITLE 1,Encounter Area
//val enc_area_raw=spark.read.parquet(f"$base_path/enc_area_raw")
//                      .withColumn("c_srt_date",to_date($"carearea_startdate","ddMMMyyyy"))
//                      .withColumn( "c_end_date"
//                              ,when(col( "carearea_enddate").isNull
//                                        ,col("c_srt_date"))
//                              .otherwise(to_date($"carearea_enddate","ddMMMyyyy")))
//                      .filter($"c_srt_date".between(startDate,endDate))
//                      .withColumn("area_dur",datediff(col("c_end_date"),col("c_srt_date")))

//display(enc_area_raw.filter($"carearea_name_cui"==="Emergency department"))

// COMMAND ----------

// DBTITLE 1,ED Visits 
val ed_visits=enc_prep.filter($"hts_patient_type_cui"===lit("CH000109"))
                      .filter($"disch_date">=$"arrive_date")
                      .withColumn("duration",datediff(col("disch_date"),col("arrive_date")))
                      .select($"ps_cci_member_id",$"enc_facilityid",$"arrive_date",$"disch_date",$"duration",$"Concept Name")
println(ed_visits.count())

// COMMAND ----------

display(
  ed_visits.groupBy("duration").count()
)

// COMMAND ----------

display(
  ed_visits.groupBy("Concept Name","duration").count()
)

// COMMAND ----------

display(ed_visits)

// COMMAND ----------

// DBTITLE 1,ED PROC Codes
val ed_procs=px.filter($"mappedcode_nodecm".isin( "G0380","G0381","G0382","G0383","G0384"
                                                 ,"99281","99282","99283","99284","99285"
                                                 ,"0450","0451","0452","0456","0459","0981"))
               .select("ps_cci_member_id","px_date")
               .distinct()
println(ed_procs.count())

// COMMAND ----------

val visits_procs=ed_visits.join(ed_procs,Seq("ps_cci_member_id"),"left")
                          .filter($"px_date">=$"arrive_date" && $"px_date"<=$"disch_date")
                          .withColumn("px_dish_date",datediff(col("px_date"),col("arrive_date")))
                          
println(visits_procs.count())
display( visits_procs )

// COMMAND ----------

val test=visits_procs.select($"ps_cci_member_id",$"arrive_date",$"px_date",$"Concept Name").distinct()
println(test.count())

// COMMAND ----------

import org.apache.spark.sql.expressions.Window

val id="ps_cci_member_id"
val start_date="arrive_date"
val end_date="px_date"

// Sort by start_date
val windowSpec=Window.partitionBy(id)
                     .orderBy(start_date)

// Create a lag column to compare with previous end_date
val dfWithLag=test.withColumn( "prev_end"
                                    ,lag(end_date,1)
                         .over(windowSpec))

// Define a flag to start a new group when there's no overlap
val dfWithFlag=dfWithLag.withColumn( "new_group"
                                    ,when(col("prev_end").isNull || col(start_date) > col("prev_end") + expr("INTERVAL 1 DAY"), 1)
                        .otherwise(0))

// Cumulative sum to assign group ids
val dfWithGroupId=dfWithFlag.withColumn( "group_id"
                                         ,sum("new_group").over(windowSpec.rowsBetween(Window.unboundedPreceding, 0)))

// Aggregate spans by group
val final_spans=dfWithGroupId.groupBy( id,"group_id")
  .agg( min(start_date).as("span_start")
       ,max(end_date).as("span_end"))
  .orderBy( id
           ,"span_start")
  .withColumn("stay_len",datediff(col("span_end"),col("span_start")))

println(final_spans.count())

// COMMAND ----------

display(final_spans.groupBy("stay_len").count())

// COMMAND ----------

// DBTITLE 1,People with Multiples
println(final_spans.groupBy("ps_cci_member_id")
          .count()
          .filter($"count">lit(1)).count())    