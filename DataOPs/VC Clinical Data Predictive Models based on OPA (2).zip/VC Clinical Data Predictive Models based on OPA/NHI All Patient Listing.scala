// Databricks notebook source
// MAGIC %fs
// MAGIC ls dbfs:/mnt/jvmlstorage2fs/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/

// COMMAND ----------

// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

val base_path=f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2"

// COMMAND ----------

val idx_dx_23=spark.read.parquet(f"$base_path/idx_dx_23/").withColumn("idx_dx_23",lit(1))
println(idx_dx_23.count())
val idx_dx_24=spark.read.parquet(f"$base_path/idx_dx_24/").withColumn("idx_dx_24",lit(1))
println(idx_dx_24.count())
val idx_enc=spark.read.parquet(f"$base_path/idx_enc/").withColumn("idx_enc",lit(1))
println(idx_enc.count())
val idx_ins=spark.read.parquet(f"$base_path/idx_ins/").withColumn("idx_ins",lit(1))
println(idx_ins.count())
val idx_obs=spark.read.parquet(f"$base_path/idx_obs/").withColumn("idx_obs",lit(1))
println(idx_obs.count())
val idx_px=spark.read.parquet(f"$base_path/idx_px/").withColumn("idx_px",lit(1))
println(idx_px.count())
val idx_rx0=spark.read.parquet(f"$base_path/idx_rx0/").withColumn("idx_rx0",lit(1))
println(idx_rx0.count())
val idx_rxa=spark.read.parquet(f"$base_path/idx_rxa/").withColumn("idx_rxa",lit(1))
println(idx_rxa.count())
val idx_rxr=spark.read.parquet(f"$base_path/idx_rxr/").withColumn("idx_rxr",lit(1))
println(idx_rxr.count())
val idx_lab=spark.read.parquet(f"$base_path/idx_lab/").withColumn("idx_lab",lit(1))
println(idx_lab.count())

// COMMAND ----------

import org.apache.spark.sql.DataFrame
val idxToJoin: Seq[DataFrame]=Seq(idx_dx_24,idx_enc,idx_ins,idx_obs,idx_px,idx_rx0,idx_rxa,idx_rxr,idx_lab)

// COMMAND ----------

val allPatKey=idxToJoin.foldLeft(idx_dx_23){(accIdx,currentIdx)=>accIdx.join(currentIdx,Seq("ps_cci_member_id"),"fullouter")}

// COMMAND ----------

allPatKey.persist()

// COMMAND ----------

allPatKey.show()

// COMMAND ----------

allPatKey.coalesce(1).write.option("header","true").mode("overwrite").csv("dbfs:/mnt/jvmlstorage2fs/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/pat_list_nhi.csv")

// COMMAND ----------

allPatKey.count()

// COMMAND ----------

allPatKey.columns

// COMMAND ----------

allPatKey.agg( sum("idx_dx_23").as("dx_23_sum")
     ,sum("idx_dx_24").as("dx_24_sum")
     ,sum("idx_enc").as("enc_sum")
     ,sum("idx_ins").as("ins_sum")
     ,sum("idx_obs").as("obs_sum")
     ,sum("idx_px").as("px_sum")
     ,sum("idx_rx0").as("rx0_sum")
     ,sum("idx_rxa").as("rxa_sum")
     ,sum("idx_rxr").as("rxr_sum")
     ,sum("idx_lab").as("lab_sum")
     ).show()

// COMMAND ----------

allPatKey.groupBy("ps_cci_member_id").count().filter($"count">1).show()

// COMMAND ----------

// DBTITLE 1,Capture Recapture Analysis
 display(allPatKey.withColumn( "idx_dx"
                              ,when($"idx_dx_24"===lit(1) || $"idx_dx_23"===lit(1)
                              ,lit(1)).otherwise(lit(0)))
                  .select( "idx_dx"
                          ,"idx_enc" 
                          ,"idx_ins" 
                          ,"idx_obs" 
                          ,"idx_px"
                          ,"idx_rx0" 
                          ,"idx_rxa" 
                          ,"idx_rxr" 
                          ,"idx_lab" ) 
                  .groupBy( "idx_dx"
                          ,"idx_enc" //,"idx_ins" 
                          ,"idx_obs" 
                          ,"idx_px"
                          ,"idx_rx0" 
                          ,"idx_rxa" 
                          ,"idx_rxr" 
                          ,"idx_lab" ).count()

 )