# Databricks notebook source
# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

# DBTITLE 1,Outcome
outcome=spark.table("ed_outcome") \
             .withColumn("outcome",lit(1))
include=spark.table("ach_dem_elig") \
             .withColumn("inc",lit(1))

fedv_outcome=include.join(outcome,on="ps_cci_member_id",how="left") \
                   .filter((col("months_tot")>=12) | (col("outcome")==1) & (col("dod_outcome") == 1)) \
                   .select("ps_cci_member_id","num_ed_visits","ED2+") \
                   .distinct() \
                   .fillna(0)  
idx=fedv_outcome.select("ps_cci_member_id")
print("Total Patient Count:",idx)
print("Unique Patient Count:",fedv_outcome.count())
print("Patients Count:")                   
print(fedv_outcome.count())
print("Duplicate ID Test(Empty Table is PASS)")
fedv_outcome.groupBy("ps_cci_member_id").count().filter(col("count")>1).show()
print("Event Count:")
fedv_outcome.groupBy("num_ed_visits","ED2+").count().orderBy("num_ed_visits").show()

# COMMAND ----------

# DBTITLE 1,Look for Imbalance in Outcomes
total=fedv_outcome.count()
display(fedv_outcome.groupBy("num_ed_visits") \
                   .count() \
                   .withColumn( "Percent"
                               , ((col("count") / total) * 100)) \
                   .orderBy("num_ed_visits")
)

# COMMAND ----------

display(fedv_outcome.groupBy("ED2+") \
                   .count() \
                   .withColumn( "Percent"
                               , ((col("count") / total) * 100)) \
                   .orderBy("ED2+")
)

# COMMAND ----------

# DBTITLE 1,MARKER Selection
# Demographic Markers
demographic=idx.join(spark.table("MARKERS.demographic"),on="ps_cci_member_id",how="inner")
demographic.show(5)
print(demographic.count())

markers=demographic
feature_cols=markers.select("marker").distinct().rdd.map(lambda x: x['marker']).collect()
print(feature_cols)

# COMMAND ----------

display(markers.groupBy("marker").count())

# COMMAND ----------

# DBTITLE 1,Marker Pivot
markers_array=markers.groupBy("ps_cci_member_id") \
                         .pivot("marker") \
                         .count().na.fill(0)
#display(markers_array)

# COMMAND ----------

model_df=fedv_outcome.join( markers_array
                          ,on="ps_cci_member_id"
                          ,how="inner")

# COMMAND ----------

# DBTITLE 1,Feature Assembly
from pyspark.ml.feature import VectorAssembler
assembler=VectorAssembler( inputCols=feature_cols
                          ,outputCol="features")

vec_df=assembler.transform(model_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Modeling Begins

# COMMAND ----------

# MAGIC %md
# MAGIC ### Logistic/Binary Classifier

# COMMAND ----------

from pyspark.ml.classification import LogisticRegression
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator

lr = LogisticRegression() \
      .setMaxIter(100) \
      .setLabelCol("ED2+") \
      .setFeaturesCol("features")

paramGrid=ParamGridBuilder() \
                   .addGrid(lr.regParam,[0.01,0.1,0.5]) \
                   .addGrid(lr.elasticNetParam,[0.0,0.5,1.0]) \
                   .build()

evaluator=MulticlassClassificationEvaluator() \
              .setLabelCol("ED2+") \
              .setPredictionCol("prediction") \
              .setMetricName("recallByLabel")

cv=CrossValidator() \
       .setEstimator(lr) \
       .setEvaluator(evaluator) \
       .setEstimatorParamMaps(paramGrid) \
       .setNumFolds(5)

cvModel = cv.fit(vec_df)

best_model=cvModel.bestModel

predictions=best_model.transform(vec_df)
print("Model Intercept:",best_model.intercept)

predictionAndAdmits = predictions.select("prediction", "ED2+") \
    .rdd.map(lambda row: (float(row[0]), float(row[1])))

# COMMAND ----------

display(predictions.groupBy("prediction").count())

# COMMAND ----------

display(predictions)

# COMMAND ----------

from pyspark.mllib.evaluation import MulticlassMetrics
metrics = MulticlassMetrics(predictionAndAdmits)
print(f"Recall (label=1.0): {metrics.recall(1.0)}")
print(f"Precision (label=1.0): {metrics.precision(1.0)}")
print(f"F1-score (label=1.0): {metrics.fMeasure(1.0)}")

# COMMAND ----------

import numpy as np
import pandas as pd
# ============================================
# COEFFICIENT ANALYSIS
# ============================================

print("\n" + "="*60)
print("COEFFICIENT ANALYSIS")
print("="*60)

# Get coefficients
coefficients = best_model.coefficients.toArray()
intercept = best_model.intercept

# Create coefficient summary
coef_summary = []
for feature, coef in zip(feature_cols, coefficients):
    coef_summary.append({
        'Feature': feature,
        'Coefficient': coef,
        'Odds_Ratio': np.exp(coef),
        'Impact': 'Positive' if coef > 0 else 'Negative'
    })

coef_df = pd.DataFrame(coef_summary)
coef_df = coef_df.sort_values('Coefficient', ascending=False)
display(coef_df)

# COMMAND ----------

print(coef_df.to_string(index=False))

# ============================================
# DETAILED INTERPRETATION
# ============================================

print("\n" + "="*60)
print("COEFFICIENT INTERPRETATION")
print("="*60)

for idx, row in coef_df.iterrows():
    feature = row['Feature']
    coef = row['Coefficient']
    odds_ratio = row['Odds_Ratio']
    
    print(f"\n{feature}:")
    print(f"  Coefficient: {coef:.4f} => Odds Ratio: {odds_ratio:.4f}")
    
    if coef > 0:
        percentage_change = (odds_ratio - 1) * 100
        print(f"  Interpretation: For {feature} the odds of admission increases by {percentage_change:.2f}%")
    else:
        percentage_change = (1 - odds_ratio) * 100
        print(f"  Interpretation: For {feature} the odds of admission deecreases by {percentage_change:.2f}%")


# COMMAND ----------

# Make predictions
predictions = best_model.transform(vec_df)

# ============================================
# STATISTICAL SUMMARY
# ============================================

print("\n" + "="*60)
print("MODEL STATISTICS")
print("="*60)

# Get training summary
summary = best_model.summary

print(f"\nAccuracy: {summary.accuracy:.4f}")
print(f"AUC-ROC: {summary.areaUnderROC:.4f}")

print("\nObjective History (Loss per iteration):")
for i, obj in enumerate(summary.objectiveHistory[:5], 1):
    print(f"  Iteration {i}: {obj:.6f}")
if len(summary.objectiveHistory) > 5:
    print(f"  ... ({len(summary.objectiveHistory)} total iterations)")

# ============================================
# KEY INSIGHTS
# ============================================

print("\n" + "="*60)
print("KEY INSIGHTS FOR COEFFICIENT INTERPRETATION")
print("="*60)

print("""
1. STANDARDIZED COEFFICIENTS:
   - Features were standardized (mean=0, std=1)
   - Coefficients represent impact of 1 standard deviation change
   - Allows direct comparison of feature importance

2. ODDS RATIOS:
   - Odds Ratio = exp(coefficient)
   - OR > 1: Feature increases odds of positive outcome
   - OR < 1: Feature decreases odds of positive outcome
   - OR = 1: Feature has no effect

3. PROBABILITY vs ODDS:
   - Odds = P(Y=1) / P(Y=0)
   - Probability = exp(linear_combination) / (1 + exp(linear_combination))
   - Linear combination = intercept + Σ(coefficient_i × feature_i)

4. PRACTICAL INTERPRETATION:
   - Look at both coefficient magnitude AND odds ratio
   - Consider business context when interpreting
   - Larger absolute coefficients = stronger predictive power
""")


# COMMAND ----------

# MAGIC %md
# MAGIC ### XGBoost Regressor

# COMMAND ----------

from xgboost.spark import SparkXGBRegressor, SparkXGBClassifier 
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator, RegressionEvaluator

xgb_regressor = SparkXGBRegressor(
     objective="count:poisson"
    ,num_workers=4
    ,tree_method="hist"
    ,nthreads=1
    ,label_col="num_ed_visits"
    ,features_col="features"
    ,missing=0.0
    ,seed=5
    ,max_depth=8
    ,learning_rate=0.05
    ,n_estimators=100
    ,verbosity=1
    ,eval_metric="poisson-nloglik"
    ,minChildWeight=5     # Regularization
    ,subsample=0.8        # Row sampling
    ,colsampleBytree=0.8  # Feature sampling
)

# Tune
param_grid = ParamGridBuilder() \
    .addGrid(xgb_regressor.reg_lambda, [0.0, 0.5, 1.0]) \
    .addGrid(xgb_regressor.reg_alpha, [0.0, 0.5, 1.0]) \
    .build()

# Evaluate
evaluator=RegressionEvaluator() \
              .setLabelCol("num_ed_visits") \
              .setPredictionCol("prediction") \
              .setMetricName("rmse")

#5FCV
cv = CrossValidator(estimator=xgb_regressor,
                    estimatorParamMaps=param_grid,
                    evaluator=evaluator,
                    numFolds=5,
                    parallelism=2)

xgb_model = cv.fit(vec_df)

bestModel = xgb_model.bestModel
predictions = bestModel.transform(vec_df)

# COMMAND ----------

from pyspark.ml.feature import Bucketizer

# Define your bin edges (splits)
splits = [0.00, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70 , 0.80, 0.90, 1.00]  
bucket_labels = {
    0.0: "Below 0.1",
    1.0: "Below 0.2",
    2.0: "Below 0.3",
    3.0: "Below 0.4",
    4.0: "Below 0.5",
    5.0: "Below 0.6",
    6.0: "Below 0.7",
    7.0: "Below 0.8",
    8.0: "Below 0.9",
    9.0: "Above 0.9",
    10.0: "Very High"
}
bucketizer = Bucketizer(
    splits=splits,
    inputCol="prediction",
    outputCol="bucket_num"
)

bucketed_df = bucketizer.transform(predictions)  
# Map bucket index to label
labeled_df = bucketed_df.withColumn(
    "bucketLabel",
    when(col("bucket_num") == 0.0, bucket_labels[0.0])
    .when(col("bucket_num") == 1.0, bucket_labels[1.0])
    .when(col("bucket_num") == 2.0, bucket_labels[2.0])
    .when(col("bucket_num") == 3.0, bucket_labels[3.0])
    .when(col("bucket_num") == 4.0, bucket_labels[4.0])
    .when(col("bucket_num") == 5.0, bucket_labels[5.0])
    .when(col("bucket_num") == 6.0, bucket_labels[6.0])
    .when(col("bucket_num") == 7.0, bucket_labels[7.0])
    .when(col("bucket_num") == 8.0, bucket_labels[8.0])
    .when(col("bucket_num") == 9.0, bucket_labels[9.0])
    .when(col("bucket_num") == 10.0, bucket_labels[10.0])
)

histogram_df = (
    labeled_df.groupBy("bucketLabel")
    .count()
    .orderBy("bucketLabel")
)

display(histogram_df)

# COMMAND ----------

import shap
# Extract the underlying XGBoost Booster from the SparkXGBRegressorModel
booster = bestModel.get_booster()

# COMMAND ----------

feature_importance = booster.get_score(importance_type='gain')
print(feature_importance)
# Map feature importance to feature names
feature_mapping = assembler.getInputCols()
print(assembler.getInputCols())
mapped_importance = {feature_mapping[int(k[1:])]: v for k, v in feature_importance.items()}

# Display feature importance
print("Feature Importance (Gain):")
for feature, importance in mapped_importance.items():
    print(f"{feature}: {importance}")

# COMMAND ----------

# Convert Spark DataFrame to pandas DataFram
pd_df=vec_df.select(*feature_cols).toPandas()
# Use TreeExplainer for XGBoost models
explainer=shap.Explainer(booster)
shap_values=explainer(pd_df)

# COMMAND ----------

shap.summary_plot(shap_values, pd_df,plot_type="bar")