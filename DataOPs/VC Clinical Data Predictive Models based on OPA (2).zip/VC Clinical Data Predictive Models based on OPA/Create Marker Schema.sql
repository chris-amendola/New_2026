-- Databricks notebook source
CREATE SCHEMA MARKERS
COMMENT 'VC Patient Level General Markers';
