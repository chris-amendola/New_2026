# Databricks notebook source
# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

bad_dupes=spark.table("drop_dopps")

# COMMAND ----------

# DBTITLE 1,Load Data for Evidence of Delivery in Outcome Period
    # --- ICD-10 Diagnosis Delivery prefixes ---
    delivery_icd10_diag_prefixes = ['O80', 'O81', 'O82', 'O83', 'O84', 'Z37']
    icd10_regex='^(' + '|'.join(delivery_icd10_diag_prefixes) + ')'
    print("ICD Delivery",icd10_regex)
    
    # --- DRG Delivery prefixes ---
    #delivery_drg_codes = #765-774

    # --- CPT/HCPCS Delivery codes  ---
    delivery_cpt_codes = [
        '59400', '59409', '59510', '59514', '59610', '59612', '59614', '59618', '59620', '59622'
    ]
    cpt_regex='^(' + '|'.join(delivery_cpt_codes) + ')'
    print("CPT Delivery",cpt_regex)

procedure=spark.read.parquet(f"{base_path}/px_raw") \
               .withColumn("px_date",to_date(col("proc_date"),"ddMMMyyyy")) \
               .filter(col("px_date").between(proStartDate,proEndDate)) \
               .filter((col("proc_codetype")=="CPT4") | (col("proc_codetype")=="HCPCS")) \
               .join( bad_dupes
                     ,"ps_cci_member_id"
                     ,"left_anti") \
               .filter(col("mappedcode_nodecm").rlike(cpt_regex)) \
               .select("ps_cci_member_id","px_date") \
               .distinct().withColumn("del_px_flag",lit(1))        
                       
diagnosis=spark.read.parquet(f"{base_path}/dx_24_raw") \
               .union(spark.read.parquet(f"{base_path}/dx_23_raw")) \
               .withColumn("dx_date",to_date(col("diag_date"),"ddMMMyyyy")) \
               .filter(col("dx_date").between(proStartDate,proEndDate)) \
               .filter(col("diag_codetype")=="ICD10") \
               .filter(((col("prim_diagnosis_flg")==1) | (col("problemlist_flag")=="Y"))) \
               .withColumn("DX_pre",regexp_replace(col("mappeddiagnosis_nodecm"),"\\.","")) \
               .filter(length(col("DX_pre"))>=3) \
               .join( bad_dupes
                     ,"ps_cci_member_id"
                     ,"left_anti") \
               .filter(col("mappeddiagnosis_nodecm").rlike(icd10_regex)) \
               .select("ps_cci_member_id","dx_date") \
               .distinct().withColumn("del_dx_flag",lit(1))        

ip_rnb=spark.read.parquet(f"{base_path}/px_raw") \
               .withColumn("px_date",to_date(col("proc_date"),"ddMMMyyyy")) \
               .filter(col("px_date").between(proStartDate,proEndDate)) \
               .filter((col("proc_codetype")=="REV")) \
               .join( bad_dupes
                     ,"ps_cci_member_id"
                     ,"left_anti") \
               .filter(col("mappedcode_nodecm").isin("0100","0110","0111","0112","0113","0120","0121","0122","0130","0131","0132","0140","0141","0142","0150","0151","0160","0161","0200","0210")) \
               .select("ps_cci_member_id","px_date") \
               .distinct().withColumn("rnb_flag",lit(1))                        

# COMMAND ----------

# Acute inpatient event (EVENT_TYPE_CUI = 'CH000106') 
# •  Exclude IP stays for baby delivery if ANY of these apply: 
# •	Principal diagnosis indicates delivery
# •	Principal procedure indicates delivery
# •	DRG indicates delivery
# •	Principal diagnosis, procedure, and DRG are all missing AND any diagnosis/procedure within the inpatient event indicates delivery

# COMMAND ----------

# DBTITLE 1,Load Encounter Data IP-Only
admits_raw=spark.read.parquet(f"{base_path}/enc_raw") \
                .filter(col("hts_patient_type_cui")==lit("CH000106")) \
                .withColumn("arrive_date",to_date(col("enc_arrivaldate"),"ddMMMyyyy")) \
                .withColumn("admit_date",to_date(col("enc_admitdate"),"ddMMMyyyy")) \
                .withColumn( "disch_date"
                            ,when( col("discharge_date").isNull()
                                  ,col("arrive_date"))
                            .otherwise(to_date(col("discharge_date"),"ddMMMyyyy"))) \
                .filter(col("arrive_date").between(proStartDate,proEndDate)) \
                .join( bad_dupes
                      ,"ps_cci_member_id"
                      ,"left_anti")

# COMMAND ----------

display(admits_raw.filter(col("ps_cci_member_id")=="123059903161474").orderBy(col("arrive_date"), col("disch_date")))

# COMMAND ----------

beg_col="arrive_date"
end_col="disch_date"
pat_id="ps_cci_member_id"

gapToleranceDays = 1

# Sort by member and begin date
w = Window.partitionBy(pat_id).orderBy(beg_col,end_col)

# Track the running maximum EndDate so far
dfWithRunningEnd = admits_raw \
  .withColumn("PrevEndDate", lag(end_col, 1).over(w)) \
  .withColumn( "RunningMaxEnd",when(col("PrevEndDate").isNull(), col(end_col))
               .otherwise(greatest(col(end_col),max(end_col).over(w.rowsBetween(Window.unboundedPreceding, -1)
       ))))

# Calculate the gap between this begin and the running maximum end so far
dfWithGroup = dfWithRunningEnd \
  .withColumn("GapDays",datediff(col(beg_col), lag(col("RunningMaxEnd"), 1).over(w))) \
  .withColumn("NewGroup",when((col("RunningMaxEnd").isNull()) | (col("GapDays") > gapToleranceDays), 1).otherwise(0)) \
  .withColumn("GroupID", sum("NewGroup").over(w))

# Combine spans per group
combinedSpans = dfWithGroup \
  .groupBy(pat_id,"GroupID") \
  .agg(min(beg_col).alias("SpanBegin"),max(end_col).alias("SpanEnd")) \
  .orderBy(pat_id, "SpanBegin") \
  .withColumn("dt_diff",datediff(col("SpanEnd"),col("SpanBegin"))) \
  .withColumn("LOS",when(col("dt_diff")==lit(0),lit(1)).otherwise(col("dt_diff")))  

# COMMAND ----------

display(dfWithRunningEnd.filter(col("ps_cci_member_id")=="123059903161474"))

# COMMAND ----------

display(dfWithGroup.filter(col("ps_cci_member_id")=="123059903161474"))

# COMMAND ----------

display(combinedSpans.filter(col("ps_cci_member_id")=="123059903161474"))

# COMMAND ----------

q=final_spans.join(ip_rnb,on="ps_cci_member_id",how="left") \
             .filter((col("px_date")>=col("span_start")) & (col("px_date")<=col("span_end"))) \
             .join(procedure,on="ps_cci_member_id",how="left") \
             .join(diagnosis,on="ps_cci_member_id",how="left") \
             .select( "ps_cci_member_id"
                     ,"group_id"
                     ,"span_start"
                     ,"span_end"
                     ,"dt_diff"
                     ,"LOS"
                     ,"rnb_flag"
                     ,"del_px_flag"
                     ,"del_dx_flag") \
                     .distinct().fillna(0) \
                     .filter(~((col("del_px_flag")==1) | (col("del_dx_flag")==1)))    

display(
     q.groupBy("rnb_flag","del_px_flag","del_dx_flag").count()
    )

# COMMAND ----------

q.write \
 .format("delta") \
 .mode("overwrite") \
 .saveAsTable("ach_outcome")