// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

// DBTITLE 1,Load Dopplegangers
val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")

// COMMAND ----------

// DBTITLE 1,Read Procedure Data
val procedure_raw=spark.read.parquet(f"$base_path/px_raw")

// COMMAND ----------


import org.apache.spark.sql.functions._

val procedure_raw_filtered = procedure_raw.filter(
  col("proc_codetype") === "ICD10" || col("proc_codetype") === "HCPCS"
)

display(procedure_raw_filtered)
procedure_raw_filtered.count()


// COMMAND ----------

// DBTITLE 1,Procedure to Treatment Category Map
val px_tx_map=spark.read
                   .option( "header"
                           ,"true")
                    .option( "inferSchema"
                            ,"true")
                    .csv(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_px_tx.csv")  

// COMMAND ----------

display(px_tx_map)

// COMMAND ----------

val px=procedure_raw_filtered.withColumn("px_date",to_date($"proc_date","ddMMMyyyy"))
                    .filter($"px_date".between(startDate,endDate))
                    .join( drop_dops
                          ,"ps_cci_member_id"
                          ,"left_anti")

// COMMAND ----------

// DBTITLE 1,Map Treatment  to Patient Procedures
val proc_tx= procedure_raw_filtered.join( px_tx_map
                      ,col("mappedprocedure")===col("Procedure_Code")
                      ,"left")
display(                      
    proc_tx.groupBy("Treatment_Code","proc_codetype").count()      
  )

// COMMAND ----------

val tx_marks=
  proc_tx.filter($"Treatment_Code".isNotNull)
         .distinct()
         .withColumn("marker",concat(lit("TX_"),col("Treatment_Code")))
         .withColumn("value",lit(1))
         .select("ps_cci_member_id","marker","value")

// COMMAND ----------

display(
  tx_marks.groupBy("marker").count()
)