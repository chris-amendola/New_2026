# Databricks notebook source
# MAGIC %fs
# MAGIC ls dbfs:/mnt/jvmlstorage2fs/jvmlshare/users/camendol/oadw_vc_modeling/EXTRACT2/

# COMMAND ----------

# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

drop_dops=spark.read.parquet(f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/chimera")

# COMMAND ----------

enc_map = (spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv"))

idx_dx_23 = (
    spark.read.parquet(f"{base_path}/dx_23_raw/")
    .filter(~col("diag_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_dx_23", lit(1))
)
print("DX_23:")
print(idx_dx_23.count())

idx_dx_24 = (
    spark.read.parquet(f"{base_path}/dx_24_raw/")
    .filter(~col("diag_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_dx_24", lit(1))
)
print("DX_24:")
print(idx_dx_24.count())

idx_enc = (
    spark.read.parquet(f"{base_path}/enc_raw/")
    .filter(~col("enc_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .join(enc_map,col("hts_patient_type_cui")==col("CUI_CODE"),"left")
    .filter(~(col("Label").isNull()))
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_enc", lit(1))
)
print("Encounter:")
print(idx_enc.count())

idx_obs = (
    spark.read.parquet(f"{base_path}/obs_raw/")
    .filter(~col("obs_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_obs", lit(1))
)
print("OBS:")
print(idx_obs.count())

idx_px = (
    spark.read.parquet(f"{base_path}/px_raw/")
    .filter(~col("proc_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_px", lit(1))
)
print("PX:")
print(idx_px.count())

idx_rx0 = (
    spark.read.parquet(f"{base_path}/rxo_raw/")
    .filter(~col("rxord_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rx0", lit(1))
)
print("RX0:")
print(idx_rx0.count())

idx_rxa = (
    spark.read.parquet(f"{base_path}/rxa_raw/")
    .filter(~col("rxadm_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rxa", lit(1))
)
print("RXA:")
print(idx_rxa.count())

idx_rxr = (
    spark.read.parquet(f"{base_path}/rxr_raw/")
    .filter(~col("rxpat_emr_source").like("int_claim%"))
    .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_rxr", lit(1))
)
print("RXR:")
print(idx_rxr.count())

idx_lab = (
    spark.read.parquet(f"{base_path}/lab_raw/")
    .filter(~col("labres_emr_source").like("int_claim%"))
    .join( drop_dops
          ,"ps_cci_member_id"
          ,"left_anti")
    .select("ps_cci_member_id")
    .distinct()
    .withColumn("idx_lab", lit(1))
)
print("LAB:")
print(idx_lab.count())

# COMMAND ----------

from pyspark.sql import DataFrame
idxToJoin: list[DataFrame] = [idx_dx_24, idx_enc, idx_obs, idx_px, idx_rx0, idx_rxa, idx_rxr, idx_lab]

# COMMAND ----------

from functools import reduce

allPatKey = reduce(
    lambda accIdx, currentIdx: accIdx.join(
        currentIdx,
        on=["ps_cci_member_id"],
        how="fullouter"
    ),
    idxToJoin,
    idx_dx_23
).withColumn(
        "idx_dx",
        when((col("idx_dx_24") == 1) | (col("idx_dx_23") == 1), 1).otherwise(0)
).withColumn( "idx_rx",
        when((col("idx_rx0") == 1) | (col("idx_rxr") == 1) | (col("idx_rxa") == 1), 1).otherwise(0)     

)
allPatKey.na.fill(0).write.mode("overwrite").saveAsTable("pat_linkeage")       

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Add Demo markers
demos=spark.read.parquet(f"{root_src}/jvmlshare/users/camendol/oadw_vc_modeling/dev_demo")
pat_link_demo=allPatKey.join(demos, on=["ps_cci_member_id"], how="leftouter")
display(pat_link_demo)

# COMMAND ----------

only_enc=allPatKey.na.fill(0) \
                  .filter(  (col("idx_lab")==0) 
                          & (col("idx_dx")==0)
                          & (col("idx_enc")==1)
                          & (col("idx_obs")==0)
                          & (col("idx_px")==0)
                          & (col("idx_rx")==0)) \
                 .select(col("ps_cci_member_id"))
print(only_enc.count())

# COMMAND ----------

display(
    allPatKey.select( col("ps_cci_member_id").alias("Patient") 
                 ,col("idx_enc").alias("Encounter") 
                 ,col("idx_obs").alias("Observation") 
                 ,col("idx_px").alias("Procedure") 
                 ,col("idx_lab").alias("Lab Results") 
                 ,col("idx_dx").alias("Diagnosis") 
                 ,col("idx_rx").alias("Medications") )
    )

# COMMAND ----------

allPatKey.count()

# COMMAND ----------

import itertools
feature_cols = ["idx_dx","idx_enc", "idx_obs", "idx_px", "idx_rx", "idx_lab"]

pairs = list(itertools.combinations(feature_cols, 2))

co_occurrence = []
for a, b in pairs:
    count = allPatKey.filter((col(a) == 1) & (col(b) == 1)).count()
    co_occurrence.append((a, b, count))

co_occur=spark.createDataFrame(co_occurrence, ["var1", "var2", "co_occurrence"])
display(co_occur)


# COMMAND ----------

capture_counts=allPatKey.agg(
        sum("idx_dx").alias("idx_dx"),
        sum("idx_enc").alias("idx_enc"),
        sum("idx_obs").alias("idx_obs"),
        sum("idx_px").alias("idx_px"),
        sum("idx_rx").alias("idx_rx"),
        sum("idx_lab").alias("idx_lab"))  \
        .withColumn("piv_point",lit("piv")) \
      .unpivot( ids=["piv_point"]
               ,values=["idx_dx","idx_enc","idx_obs","idx_px","idx_rx","idx_lab"]
               ,variableColumnName="key",valueColumnName="value") \
      .withColumn("Found",col("value")/allPatKey.count()
     ).withColumn("Not Found",lit(1)-col("Found"))

display(capture_counts)   
# Persist the dataframe to a table
capture_counts.write.mode("overwrite").saveAsTable("capture_counts")


# COMMAND ----------

# MAGIC %md
# MAGIC ![USA_on_DRUGS.jpg](./USA_on_DRUGS.jpg "USA_on_DRUGS.jpg")
# MAGIC
# MAGIC Regarding Labs:
# MAGIC https://www.cdc.gov/nchs/data/nhsr/nhsr184.pdf
# MAGIC
# MAGIC ### An examination or screening was 
# MAGIC ### ordered or provided at nearly 
# MAGIC ### one-half (47.6%) of all office-based 
# MAGIC ### physician visits, followed by 
# MAGIC ### **_laboratory tests (24.2%)_**, health 
# MAGIC ### education or counseling (20.0%), 
# MAGIC ### imaging (13.1%), and procedures 
# MAGIC ### (12.0%) (Figure 4, Table 4).

# COMMAND ----------

# DBTITLE 1,Simple Formula - Peterson Estimations of Population Size
display(co_occur.join( capture_counts.select( col("key").alias("key1"),
                                    col("value").alias("var1_n"))
                      ,col("var1")==col("key1"),"left")
                .join( capture_counts.select( col("key").alias("key2")
                                             ,col("value").alias("var2_n"))
                      ,col("var2")==col("key2"),"left")
                .withColumn("Est_N",(col("var1_n")*col("var2_n"))/col("co_occurrence"))
                .withColumn("Diff",col("Est_N")-allPatKey.count())
                .withColumn("Diff",round(col("Diff"), 0))
                .withColumn("Prop",col("Est_N")/allPatKey.count())
                .orderBy(col("Diff").desc())
)


# COMMAND ----------

allPatKey.groupBy("ps_cci_member_id").count().filter(col("count") > 1).show()

# COMMAND ----------

# DBTITLE 1,Capture Recapture Analysis
cap_matrix = (
    allPatKey
    .select(
        "idx_dx",
        "idx_enc",
        "idx_obs",
        "idx_px",
        "idx_rx",
        "idx_lab"
    )
    .groupBy(
        "idx_dx",
        "idx_enc",
        "idx_obs",
        "idx_px",
        "idx_rx",
        "idx_lab"
    )
    .count()
    .na.fill(0)
)

display(cap_matrix)
# Persist the dataframe to a table
cap_matrix.write.mode("overwrite").saveAsTable("cap_matrix")