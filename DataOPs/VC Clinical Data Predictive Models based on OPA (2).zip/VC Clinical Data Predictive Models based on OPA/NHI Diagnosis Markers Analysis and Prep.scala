// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

// DBTITLE 1,Load Dopplegangers
val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")

// COMMAND ----------

println(drop_dops.count())

// COMMAND ----------

// DBTITLE 1,Clinical  Conditions SR  - MAP
// Clinical Condition SR, from Impact Intelligence Team 
val ccsr_map = spark.read
  .format("csv")
  .option("header", "true")
  .option("inferSchema", "true")
  .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/MAP_DXCCSR_DX2CAT.csv")
  .withColumn("3-Character Abbreviation",substring($"CCSR Category",1,3))

val ccsr_descs=ccsr_map.select("CCSR Category","CCSR Category Description").distinct()  

val ccsr_topcats = spark.read
    .format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/MAP_DXCCSR_SUMCAT_DESC.csv")

// COMMAND ----------

// DBTITLE 1,Raw Diag
val raw_dx=spark.read.parquet(f"$base_path/dx_24_raw")
                .union(spark.read.parquet(f"$base_path/dx_23_raw"))

// COMMAND ----------

// DBTITLE 1,Diag Data Preparation
val dx=raw_dx.withColumn("dx_date",to_date($"diag_date","ddMMMyyyy"))
             .filter($"dx_date".between(startDate,endDate))
             .filter($"diag_codetype"==="ICD10")
             .filter($"prim_diagnosis_flg"===1 || $"problemlist_flag"==="Y")
             .withColumn("DX_pre",regexp_replace(col("mappeddiagnosis"),"\\.",""))
             .filter(length($"DX_pre")>3)
             .join( drop_dops
                   ,"ps_cci_member_id"
                   ,"left_anti")

val ccsr_dx=dx.join(ccsr_map,dx("DX_pre")===ccsr_map("ICD-10-CM Code"))
val clin_pat_conds=ccsr_dx.select( "ps_cci_member_id"
                                  ,"CCSR Category"
                                  ,"CCSR Category Description")
                          .distinct()                    

// COMMAND ----------

println(raw_dx.count())
println(dx.count())

// COMMAND ----------

display(dx)

// COMMAND ----------

val clin_condtion_marks=clin_pat_conds.withColumnRenamed("CCSR Category", "marker")
                                      .select("ps_cci_member_id","marker")
                                      .withColumn("value",lit(1))

// COMMAND ----------

display(clin_condtion_marks)

// COMMAND ----------

display(clin_condtion_marks)

// COMMAND ----------

clin_condtion_marks
  .orderBy("ps_cci_member_id")
  .limit(10000)
  .display(10000)

// COMMAND ----------

import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.FileOutputStream
val df = clin_condtion_marks.orderBy("ps_cci_member_id").limit(10000)
val data = df.collect()

val workbook = new XSSFWorkbook()
val sheet = workbook.createSheet("Sheet1")

// Write header
val header = sheet.createRow(0)
df.columns.zipWithIndex.foreach { case (name, idx) =>
  header.createCell(idx).setCellValue(name)
}

// Write data
data.zipWithIndex.foreach { case (row, i) =>
  val excelRow = sheet.createRow(i + 1)
  for (j <- 0 until row.size) {
    excelRow.createCell(j).setCellValue(row.get(j).toString)
  }
}

// Save file
val out = new FileOutputStream("/Workspace/Users/sshar699@optumcloud.com/clin_condition_marks.xlsx")
workbook.write(out)
out.close()
workbook.close()

// COMMAND ----------

println(clin_condtion_marks.count())