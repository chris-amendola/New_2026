# Databricks notebook source
# MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config_python"

# COMMAND ----------

bad_dupes=spark.table("drop_dopps")

# COMMAND ----------

# DBTITLE 1,Raw ED Visit Load in and Clean
ed_vis_raw=spark.read.parquet(f"{base_path}/enc_raw") \
                .filter(col("hts_patient_type_cui")==lit("CH000109")) \
                .withColumn("arrive_date",to_date(col("enc_arrivaldate"),"ddMMMyyyy")) \
                .withColumn("admit_date",to_date(col("enc_admitdate"),"ddMMMyyyy")) \
                .withColumn( "disch_date"
                            ,when( col("discharge_date").isNull()
                                  ,col("arrive_date"))
                            .otherwise(to_date(col("discharge_date"),"ddMMMyyyy"))) \
                .filter(col("arrive_date").between(proStartDate,proEndDate)) \
                .filter(col("disch_date")>=col("arrive_date")) \
                .join( bad_dupes
                      ,"ps_cci_member_id"
                      ,"left_anti")

# COMMAND ----------

beg_col="arrive_date"
end_col="disch_date"
pat_id="ps_cci_member_id"

gapToleranceDays = 1

# Sort by member and begin date
w = Window.partitionBy(pat_id).orderBy(beg_col,end_col)

# Track the running maximum EndDate so far
dfWithRunningEnd = ed_vis_raw \
  .withColumn("PrevEndDate", lag(end_col, 1).over(w)) \
  .withColumn( "RunningMaxEnd",when(col("PrevEndDate").isNull(), col(end_col))
               .otherwise(greatest(col(end_col),max(end_col).over(w.rowsBetween(Window.unboundedPreceding, -1)
       ))))

# Calculate the gap between this begin and the running maximum end so far
dfWithGroup = dfWithRunningEnd \
  .withColumn("GapDays",datediff(col(beg_col), lag(col("RunningMaxEnd"), 1).over(w))) \
  .withColumn("NewGroup",when((col("RunningMaxEnd").isNull()) | (col("GapDays") > gapToleranceDays), 1).otherwise(0)) \
  .withColumn("GroupID", sum("NewGroup").over(w))

# Combine spans per group
combinedSpans = dfWithGroup \
  .groupBy(pat_id,"GroupID") \
  .agg(min(beg_col).alias("SpanBegin"),max(end_col).alias("SpanEnd")) \
  .orderBy(pat_id, "SpanBegin") \
  .withColumn("dt_diff",datediff(col("SpanEnd"),col("SpanBegin"))) \
  .withColumn("Duration Days",when(col("dt_diff")==lit(0),lit(1)).otherwise(col("dt_diff")))  

# COMMAND ----------

from pyspark.sql.functions import count
display( combinedSpans.groupBy("ps_cci_member_id")
        .count()
        .groupBy("count")
        .agg( count("*")
             .alias("freq")))



# COMMAND ----------

display( combinedSpans.groupBy("ps_cci_member_id")
        .count()
        )

# COMMAND ----------

display(combinedSpans.filter(col("ps_cci_member_id")==lit(12305278975414)).orderBy("GroupID"))

# COMMAND ----------

# DBTITLE 1,Load In IP Admits
display(spark.table("ach_outcome"))

# COMMAND ----------

ip_evts=spark.table("ach_outcome").select( col("ps_cci_member_id")
                                          ,col("span_start").alias("ip_start")
                                          ,col("span_end").alias("ip_end")
                                          ,col("group_id").alias("ip_num"))
display(ip_evts)

# COMMAND ----------

ed_evts=combinedSpans.select( col("ps_cci_member_id")
                                  ,col("SpanBegin").alias("ed_start")
                                  ,col("SpanEnd").alias("ed_end")
                                  ,col("GroupID").alias("ed_num"))
print(ed_evts.count())
ed_evts.groupBy("ps_cci_member_id").count().groupBy("count").agg(count('*').alias("freq")).orderBy("count").show()
#display(ed_evts)

# COMMAND ----------

ed_ip_drops=(ed_evts.join(ip_evts,on="ps_cci_member_id",how="left")
                  .withColumn( "convert_ip"
                              ,when(abs(datediff(col("ed_end"),col("ip_start")))==0,lit("Y")).otherwise(lit("N")))
                   .orderBy("ps_cci_member_id","ip_num","ed_num").filter(col("convert_ip")==lit("Y")))

# COMMAND ----------

display(ed_ip_drops.groupBy("ps_cci_member_id","ed_num").count().filter(col("count")>lit(1)))

# COMMAND ----------

ed_ip_drops.groupBy("convert_ip").count().show()

# COMMAND ----------

# DBTITLE 1,Anti Join IP Conversion ED Visits
ed_non_ip=ed_evts.join(ed_ip_drops,on=["ps_cci_member_id","ed_start","ed_end"],how="leftanti")
ed_non_ip.show(5)

# COMMAND ----------

ed_non_ip.groupBy("ps_cci_member_id").count().groupBy("count").agg(count('*').alias("freq")).orderBy("count").show()

# COMMAND ----------

ed_outcome=ed_non_ip.groupBy("ps_cci_member_id").agg(count('*').alias("num_ed_visits")) \
                    .withColumn("ED2+",when(col("num_ed_visits")>=lit(2),lit(1)).otherwise(lit(0)))
ed_outcome.show(5)

# COMMAND ----------

ed_outcome.write \
 .format("delta") \
 .mode("overwrite") \
 .option("mergeSchema", "true").saveAsTable("ed_outcome")