// Databricks notebook source
// MAGIC %run "/Workspace/Users/camendo2@optumcloud.com/VC Clinical Data Predictive Models based on OPA/Config"

// COMMAND ----------

// DBTITLE 1,Duplicates
val drop_dops=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/dopplegangers")

// COMMAND ----------

// DBTITLE 1,Payer Data - Elig Pats
val ret_elg_idx=spark.read.parquet(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/retro_pats_idx")
println(ret_elg_idx.count())

// COMMAND ----------

// DBTITLE 1,Encounter MAPS
val enc_map = spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_encounter_desc.csv")
enc_map.show()
val disp_cat_map=spark.read
                   .format("csv")
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .load(f"$root_src/jvmlshare/users/camendol/oadw_vc_modeling/map_disp_cat.csv")
                   .withColumnRenamed("Concept Name","Concept_Name")

// COMMAND ----------

// DBTITLE 1,Raw Encounter
val enc_raw=spark.read.parquet(f"$base_path/enc_raw")
                 .withColumn("arrive_date",to_date($"enc_arrivaldate","ddMMMyyyy"))
                 .withColumn("admit_date",to_date($"enc_admitdate","ddMMMyyyy"))
                 .withColumn( "disch_date"
                              ,when(col( "discharge_date").isNull
                                        ,col("arrive_date"))
                              .otherwise(to_date($"discharge_date","ddMMMyyyy")))
                 .join( drop_dops
                       ,"ps_cci_member_id"
                       ,"left_anti")
//enc_raw.columns

// COMMAND ----------

println(enc_raw.count())
print(enc_raw.select("ps_cci_member_id").distinct().count())

// COMMAND ----------

// DBTITLE 1,Filter/Prep/Map
val enc_prep=enc_raw.filter($"arrive_date".between(startDate,endDate))
                    .filter(not($"enc_emr_source".like("int_claim%")))
                    .join(enc_map,enc_raw("hts_patient_type_cui")===enc_map("CUI_CODE"),"left")
                    .join(disp_cat_map,enc_raw("discharge_disp_m")===disp_cat_map("Concept_CUI"),"left")

println(enc_prep.count())
println(enc_prep.select("ps_cci_member_id").distinct().count())
enc_prep.write 
        .format("delta")   
        .mode("overwrite")  
        .saveAsTable("enc_prep")

// COMMAND ----------

enc_raw.columns

// COMMAND ----------

// DBTITLE 1,MARKERS
val enc_marks=
  enc_prep.filter($"CUI_CODE".isNotNull)
          .distinct()
          .withColumn("marker",concat(lit("ENC_"),col("CUI_CODE")))
          .withColumn("value",lit(1))
          .select("ps_cci_member_id","marker","value")

// COMMAND ----------

display(enc_marks.groupBy("marker").count())

// COMMAND ----------

// DBTITLE 1,Some QA
display(enc_prep.groupBy("hts_patient_type_cui","Label","enc_groupid").count())

// COMMAND ----------

val grouped = enc_prep
  .select("ps_cci_member_id", "enc_groupid")
  .distinct()
  .groupBy("ps_cci_member_id")
  .count()
  .groupBy("count")
  .agg(count("count").alias("freq"))

// COMMAND ----------

val total = grouped.agg(sum("freq").alias("fq_ct"))

val result = grouped.crossJoin(total)
  .withColumn(
    "percent",
    col("freq") / col("fq_ct")
  )

display(result)

// COMMAND ----------

